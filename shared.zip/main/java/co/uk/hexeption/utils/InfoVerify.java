package co.uk.hexeption.utils;
import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class InfoVerify {
    public static String get(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();

        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
            response.append("\n");
        }

        in.close();

        return response.toString();
    }

    public static void displayTray(String Title, String Text, TrayIcon.MessageType type) throws AWTException {
        SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("System tray icon demo");
        tray.add(trayIcon);
        trayIcon.displayMessage(Title, Text, type);
    }

    //调用
    public static void Logins() throws AWTException {
        try {
            //例子:if (get("https://gitee.com/nightqing/YeQing/raw/master/ConfusionAC").contains(getHwid()))
            if (get("https://gitee.com/Sloar233/tamper-sense-hwidkonfig-t/raw/master/HWID").contains(getHwid())) {
                displayTray("Tamper", "验证成功", TrayIcon.MessageType.WARNING);
            } else {
                displayTray("Tamper", "验证失败", TrayIcon.MessageType.ERROR);
                JOptionPane.showInputDialog(null, "已复制到粘贴板,发送于管理员", getHwid());
                copyToClipboard(getHwid());
                System.exit(0);
            }
        } catch (IOException | NoSuchAlgorithmException e) {
            JOptionPane.showMessageDialog(null, "服务器连接失败!", "Tamper", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    //获取Hwid
    public static String getHwid() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        StringBuilder s = new StringBuilder();
        String main = System.getenv("PROCESS_IDENTIFIER") + System.getenv("COMPUTERNAME");
        byte[] bytes = main.getBytes(StandardCharsets.UTF_8);
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] md5 = messageDigest.digest(bytes);
        int i = 0;
        for (byte b : md5) {
            s.append(Integer.toHexString((b & 0xFF) | 0x300), 0, 3);
            if (i != md5.length - 1) {
                s.append("-");
            }
            i++;
        }
        return s.toString();
    }

    //自动复制
    public static void copyToClipboard(String string) {
        StringSelection stringSelection = new StringSelection(string);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
    }
}