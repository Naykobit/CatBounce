package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.EntityUtils2
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.Minecraft
import java.awt.Color

@ModuleInfo(name = "BetterHotBar", category = ModuleCategory.RENDER, description = "CatBounce", cn = "更好的物品栏")
class BetterHotBar : Module() {
    private val modeValue = ListValue("bar", arrayOf("Black","Lite", "Off"), "Off")
    private val fontvalue = BoolValue("Info", true)
    private val girlvalue = ListValue("girl", arrayOf("Crygirl","Happygirl","Move0","Move1","Move2","Bluecat", "Liuli", "Off"),"Off")
    private val colorModeValue = ListValue("InfoColor", arrayOf("Custom", "GodLightSync","novo","rainbow","skyrainbow","anptherrainbow"), "Custom")
    private val RedValue = IntegerValue("R", 255, 0, 255)
    private val GreenValue = IntegerValue("G", 255, 0, 255)
    private val BlueValue = IntegerValue("B", 255, 0, 255)
    private val AlphaValue = IntegerValue("A", 255,0,255)
    private val rainbowSpeed = IntegerValue("RainbowSpeed", 10, 1, 10)
    private val rainbowIndex = IntegerValue("RainbowIndex", 1, 1, 20)
    private val offsetValue = IntegerValue("Y-Offset", 36, -50, 100)


    private var Black = classProvider.createResourceLocation("catbounce/hud/betterhud1.png")
    private var Lite = classProvider.createResourceLocation("catbounce/hud/betterhud2.png")
    private var crygirl = classProvider.createResourceLocation("catbounce/girls/crygirl.png")
    private var happygirl = classProvider.createResourceLocation("catbounce/girls/happygirl.png")
    private var bluecat = classProvider.createResourceLocation("catbounce/girls/bluecat.png")
    private var liuli = classProvider.createResourceLocation("catbounce/girls/liuli.png")
    private var move0 = classProvider.createResourceLocation("catbounce/girls/0.png")
    private var move1 = classProvider.createResourceLocation("catbounce/girls/1.png")
    private var move2 = classProvider.createResourceLocation("catbounce/girls/2.png")




    @EventTarget
    fun onRender(event: Render2DEvent) {
        val TextColor = when (colorModeValue.get().toLowerCase()) {
            "novo" -> ColorUtils.novoRainbow(40).rgb
            "rainbow" -> ColorUtils.hslRainbow(rainbowIndex.get(), indexOffset = 100 * rainbowSpeed.get()).rgb
            "skyrainbow" -> me.utils.render.RenderUtils.skyRainbow(rainbowIndex.get(), 1F, 1F).rgb
            "anotherrainbow" -> ColorUtils.fade(Color(RedValue.get(), GreenValue.get(), BlueValue.get(), AlphaValue.get()), 100, rainbowIndex.get()).rgb
            "godlightsync"-> ColorUtils.GodLight(40).rgb
            else -> Color(RedValue.get(), GreenValue.get(), BlueValue.get(), 1).rgb
        }
        when (modeValue.get()) {
            "Black" -> drawhud(Black)
            "Lite" -> drawhud(Lite)
        }

        when(girlvalue.get()) {
            "Crygirl" -> drawgirl(crygirl)
            "Happygirl" -> drawgirl(happygirl)
            "Bluecat" -> drawgirl(bluecat)
            "Move0" -> drawgirl(move0)
            "Move1" -> drawgirl(move1)
            "Move2" -> drawgirl(move2)
            "Liuli" -> drawgirl(liuli)
        }


        if (fontvalue.get()) {

        Fonts.sfbold35.drawStringWithShadow("FPS:" + Minecraft.getDebugFPS(),5,495 + offsetValue.get(),TextColor)
       // Fonts.flux.drawString("k",7F,496F + offsetValue.get(), Color(11,143,180).rgb)

        Fonts.sfbold35.drawStringWithShadow("Ping:" + EntityUtils2.getPing(mc.thePlayer),5,520 + offsetValue.get(),TextColor)
      //  Fonts.flux.drawString("k",130F,496F + offsetValue.get(), Color(11,143,180).rgb)

        Fonts.sfbold35.drawStringWithShadow("BPS:" + calculateBPS(),5,540 + offsetValue.get(),TextColor)
       // Fonts.flux.drawString("k",257F,496F + offsetValue.get(), Color(11,143,180).rgb)

       // Fonts.com35.drawString("ServerIP:" + ServerUtils.getRemoteIp(),780F,560F + offsetValue.get(),-1)
       // Fonts.flux.drawString("k",767F,496F + offsetValue.get(), Color(11,143,180).rgb)
        }
    }
    fun calculateBPS(): Double {
        if(mc.thePlayer != null) {
            val bps = Math.hypot(
                mc.thePlayer!!.posX - mc.thePlayer!!.prevPosX,
                mc.thePlayer!!.posZ - mc.thePlayer!!.prevPosZ
            ) * mc.timer.timerSpeed * 20
            return Math.round(bps * 100.0) / 100.0
        }else{
            return 0.00
        }

    }
    fun drawhud(resource: IResourceLocation) = RenderUtils.drawImage(resource,-8,487 + offsetValue.get(),1920,45)
    fun drawgirl(resource: IResourceLocation) = RenderUtils.drawImage(resource,570,415 + offsetValue.get(),100,100)

}

