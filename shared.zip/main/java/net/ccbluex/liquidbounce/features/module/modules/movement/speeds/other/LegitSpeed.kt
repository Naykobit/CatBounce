/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.features.module.modules.movement.GrimStrafe
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class LegitSpeed : SpeedMode("LegitSpeed") {
    private lateinit var killAura: KillAura
    private lateinit var grimStrafe: GrimStrafe
    var a = 0
    override fun onMotion(event: MotionEvent) {
        mc.timer.timerSpeed = 1.004f
        if (mc.thePlayer!!.isInWater) return
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        grimStrafe = LiquidBounce.moduleManager.getModule(GrimStrafe::class.java) as GrimStrafe
        if (!killAura.state) {
            if (mc.thePlayer!!.onGround) {
                mc.gameSettings.keyBindJump.pressed = true
            } else mc.gameSettings.keyBindJump.pressed = false
        }else if (mc.gameSettings.keyBindForward.isKeyDown){
            if (mc.thePlayer!!.onGround) {
                a += 1
            } else{
                a = 0
            }
            if (a >= grimStrafe.jumpdelayValue.get()) {
                mc.gameSettings.keyBindJump.pressed = true
            } else mc.gameSettings.keyBindJump.pressed = false
        }
    }

    override fun onUpdate() {
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1.0f
        mc.gameSettings.keyBindJump.pressed = false
    }
    override fun onMove(event: MoveEvent) {}
}