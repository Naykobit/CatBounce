/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.misc.Reallyhurt
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "ModeChange", description = "catbounce", category = ModuleCategory.COMBAT, cn = "击退模式")
class Wtap : Module() {
    private lateinit var killAura: KillAura
    private lateinit var superKnockback: SuperKnockback
    private lateinit var safeauramode: Safeauramode
    private lateinit var reallyhurt: Reallyhurt
    val kbgroundRangeValue = FloatValue("KbGroundRange", 3.55f, 1f, 8f)
    val kbairRangeValue = FloatValue("KbAirRange", 3.27f, 1f, 8f)
    val BalantgroundRangeValue = FloatValue("BalantGroundRange", 3.8f, 1f, 8f)
    val BalantairRangeValue = FloatValue("BalantAirRange", 3.5f, 1f, 8f)

    override fun onEnable() {
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        reallyhurt = LiquidBounce.moduleManager.getModule(Reallyhurt::class.java) as Reallyhurt
        safeauramode = LiquidBounce.moduleManager.getModule(Safeauramode::class.java) as Safeauramode
        superKnockback = LiquidBounce.moduleManager.getModule(SuperKnockback::class.java) as SuperKnockback
        killAura.hyt180fovfixValue.set(true)
        killAura.silentfix.set(true)
        killAura.rotationStrafeValue.set("Silent")
        killAura.jumpfix2.set(true)
        killAura.jumpfix.set(false)
        killAura.groundRangeValue.set(kbgroundRangeValue.get())
        killAura.airRangeValue.set(kbairRangeValue.get())
        reallyhurt.normalgroundrangeValue.set(kbgroundRangeValue.get())
        reallyhurt.normalairrangeValue.set(kbairRangeValue.get())
        safeauramode.normalgroundrangeValue.set(kbgroundRangeValue.get())
        safeauramode.normalairrangeValue.set(kbairRangeValue.get())
    }

    override fun onDisable() {
        killAura.hyt180fovfixValue.set(false)
        killAura.silentfix.set(false)
        killAura.jumpfix2.set(false)
        killAura.jumpfix.set(true)
        killAura.rotationStrafeValue.set("Strict")
        killAura.groundRangeValue.set(BalantgroundRangeValue.get())
        killAura.airRangeValue.set(BalantairRangeValue.get())
        reallyhurt.normalgroundrangeValue.set(BalantgroundRangeValue.get())
        reallyhurt.normalairrangeValue.set(BalantairRangeValue.get())
        safeauramode.normalgroundrangeValue.set(BalantgroundRangeValue.get())
        safeauramode.normalairrangeValue.set(BalantairRangeValue.get())
    }
}