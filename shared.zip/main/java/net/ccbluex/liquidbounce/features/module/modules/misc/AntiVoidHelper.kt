package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.ScaffoldLB
import net.ccbluex.liquidbounce.value.IntegerValue

@ModuleInfo(name = "AntiVoidHelper", category = ModuleCategory.MISC, description = "CatBounce", cn = "反虚空助手")
class AntiVoidHelper : Module() {
    private val X = IntegerValue("ticks", 20, -0, 100)
    var Y = X.get()
    override fun onEnable() {
        Y = X.get()
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val scaffoldLB = LiquidBounce.moduleManager.getModule(ScaffoldLB::class.java) as ScaffoldLB
        val hytantivoidhelper = LiquidBounce.moduleManager.getModule(AntiVoidHelper::class.java) as AntiVoidHelper
        if (Y != 0){
            scaffoldLB.state = true
            Y -= 1
        }else{
            scaffoldLB.state = false
            hytantivoidhelper.state = false
        }
    }
}