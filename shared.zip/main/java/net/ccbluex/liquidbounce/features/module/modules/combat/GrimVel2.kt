package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayClient
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketConfirmTransaction
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.network.play.server.SPacketPlayerPosLook
import java.util.*
import java.util.concurrent.LinkedBlockingQueue

/**
 * * Thanks kid(qwa)、FDPClient
*  Fix by 小猫很可爱 修复Lag 原地不动开get ban 等等问题
 */

@ModuleInfo(name = "GrimVel2", description = "网卡时使用我会嘎嘎flag哦",cn="不动如山2", category = ModuleCategory.COMBAT)
class GrimVel2 : Module() {
    private val modeValue = ListValue("Mode", arrayOf("FDP","New"),"New")
    private val disable = BoolValue("S08Disable",true)
    private val airsafe = BoolValue("airsafe",true)
    private val cancleCpacket = BoolValue("cancleCpacket",true)
    private val test = BoolValue("test",true)
    private val safeping = BoolValue("safeping",true)
    private val safepingvalue = IntegerValue("safepingvalue", 30, 1, 1000)
    private val onlyCombatValue = BoolValue("OnlyCombat",true)
    private val onlyGroundValue = BoolValue("OnlyGround",true)
    private val nomovebypass = BoolValue("nomovebypass",true)
    private val reEnable = BoolValue("ReEnable",true)

    //FDP
    private var cancelPacket = 6
    private var resetPersecFDP = 8
    private var grimTCancel = 0
    private var updatesFDP = 0

    //Kid
    private var cancelPackets = 0
    private var resetPersec = 8
    private var updates = 0

    //VelocityBlink调用的函数
    //startBlink()
    //closeblink()
    private val packets = LinkedBlockingQueue<Packet<*>>()
    private var disableLogger = false
    private val inBus = LinkedList<Packet<INetHandlerPlayClient>>()


    override fun onEnable() {
        grimTCancel = 0
        cancelPackets = 0
    }
    override fun onDisable(){
        if (modeValue.get().equals("New")) {
            closeblink()
        }
        if (!mc.thePlayer!!.onGround){
            val velocity = LiquidBounce.moduleManager.getModule(GrimVel::class.java) as GrimVel
            velocity.state = true
        }
    }
    @EventTarget
    open fun isfulldowndamage(): Boolean {
        for (i in 0..3) {
            if (MovementUtils.isOnGround(i.toDouble())) {
                return false
            }
        }
        return true
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val thePlayer = mc.thePlayer ?: return
        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return
        if (mc.thePlayer!!.burning) return
        if (mc.thePlayer!!.fallDistance > 3F) return
        if ((onlyGroundValue.get() && !mc.thePlayer!!.onGround) || (onlyCombatValue.get() && !LiquidBounce.combatManager.inCombat)) {
            return
        }
        val packet = event.packet
        val packet1 = event.packet.unwrap()
        fun startBlink(){
            val packet2 = event.packet.unwrap()
            if (mc.thePlayer == null || disableLogger) return
            if (cancleCpacket.get()) {
                if (packet2 is CPacketPlayer)
                    event.cancelEvent()
                if (packet2 is CPacketPlayer.Position || packet2 is CPacketPlayer.PositionRotation ||
                    packet2 is CPacketPlayerTryUseItemOnBlock ||
                    packet2 is CPacketAnimation ||
                    packet2 is CPacketEntityAction || packet2 is CPacketUseEntity || (packet2::class.java.simpleName.startsWith(
                        "C",
                        true
                    ))
                ) {
                    event.cancelEvent()
                    packets.add(packet2)
                }
            }
            if(packet2::class.java.getSimpleName().startsWith("S", true)) {
                if(packet2 is SPacketEntityVelocity && (mc.theWorld?.getEntityByID(packet2.entityID) ?: return) == mc.thePlayer){return}
                event.cancelEvent()
                inBus.add(packet2 as Packet<INetHandlerPlayClient>)
            }
        }
        when(modeValue.get()){
            "FDP" -> {
                if (MovementUtils.isMoving) {
                    if (classProvider.isSPacketEntityVelocity(packet)) {
                        val packetEntityVelocity = packet.asSPacketEntityVelocity()

                        if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                            return

                        event.cancelEvent()
                        grimTCancel = cancelPacket
                    }
                    if (packet1 is SPacketConfirmTransaction && grimTCancel > 0) {
                        event.cancelEvent()
                        grimTCancel--
                    }
                }
            }
            "New" -> {
                if (packet1 is SPacketEntityVelocity) {
                    val packetEntityVelocity = packet.asSPacketEntityVelocity()
                    if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                        return

                    event.cancelEvent()
                    cancelPackets = 2
                }
                if(cancelPackets > 0){
                    startBlink()
                }
            }
        }

        //Auto Disable
        if (packet1 is SPacketPlayerPosLook){
            if (disable.get()){
                val velocity = LiquidBounce.moduleManager.getModule(GrimVel::class.java) as GrimVel
                if ((mc.thePlayer!!.onGround && airsafe.get()) || !airsafe.get()) velocity.state = false
                if (reEnable.get()){
                    Thread {
                        try {
                            Thread.sleep(1000)
                            velocity.state = true
                        } catch (ex: InterruptedException) {
                            ex.printStackTrace()
                        }
                    }.start()
                }
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return
        if (mc.thePlayer!!.burning) return
        if (mc.thePlayer!!.fallDistance > 3F) {
            mc.gameSettings.keyBindJump.pressed = false
            return}
        if (isfulldowndamage() && test.get()) mc.gameSettings.keyBindJump.pressed = false
        if (safeping.get() && EntityUtils.getPing(mc2.player!!).toString() >= safepingvalue.get().toString()){
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d你的网络延迟极大，请立即关闭全反！！！全反只能在地上关闭！！！不能在空中关哦")
        }
        if ((onlyGroundValue.get() && !mc.thePlayer!!.onGround) || (onlyCombatValue.get() && !LiquidBounce.combatManager.inCombat)) {
            return
        }
        updatesFDP++

        if(nomovebypass.get() && !MovementUtils.isMoving && mc.thePlayer!!.onGround
                && mc.thePlayer!!.hurtTime == 9 && mc.thePlayer!!.motionX == 0.0
                && mc.thePlayer!!.motionZ == 0.0 && mc.thePlayer!!.health > 0
                && !mc.gameSettings.keyBindJump.isKeyDown) mc.thePlayer!!.jump()

        if (resetPersecFDP > 0) {
            if (updatesFDP >= 0 || updatesFDP >= resetPersecFDP) {
                updatesFDP = 0
                if (grimTCancel > 0) {
                    grimTCancel--
                }
            }
        }
        updates++
        if (resetPersec > 0) {
            if (updates >= 0 || updates >= resetPersec) {
                updates = 0
                if (cancelPackets > 0){
                    cancelPackets--
                }
            }
        }
        if(cancelPackets == 0){
            if (modeValue.get().equals("New")){
                closeblink()
            }
        }
    }
    private fun closeblink() {
        try {
            disableLogger = true
            while (!packets.isEmpty()) {
                mc2.connection!!.networkManager.sendPacket(packets.take())
            }
            while (!inBus.isEmpty()) {
                inBus.poll()?.processPacket(mc2!!.connection)
            }
            disableLogger = false
        } catch (e: Exception) {
            e.printStackTrace()
            disableLogger = false
        }
    }
    override val tag: String?
        get() = "LatestGrimac"
}