/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.api.enums.BlockType
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue

@ModuleInfo(name = "Eagle", category = ModuleCategory.PLAYER, description = "CatBounce", cn = "合法蹲搭")
class Eagle : Module() {

    private val motionPredictValue = FloatValue("MotionPredictAmount", 0.2f, 0.0f, 2.0f)
    private val limitTimeValue = BoolValue("SneakTimeLimit", false)
    private val holdTime = IntegerValue("MaxSneakTime", 120, 0, 900)
    private val onlyGround = BoolValue("OnlyGround", true)
    private val onlyLookingDown = BoolValue("OnlyLookingDown", true)
    private val onlyMovingBack = BoolValue("OnlyMovingBack", true)

    private val holdTimer = MSTimer()

    private var sneakValue = false

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        if (!limitTimeValue.get()) {
            sneakValue = false
        }
        if ( ( !onlyGround.get() || mc.thePlayer!!.onGround ) && ( !onlyLookingDown.get() || mc.thePlayer!!.rotationPitch.toDouble() > 65.0 ) && ( !onlyMovingBack.get() || mc.gameSettings.keyBindBack.pressed ) &&
            mc.theWorld!!.getBlockState(WBlockPos(thePlayer.posX, thePlayer.posY - 1.0, thePlayer.posZ)).block == classProvider.getBlockEnum(
                BlockType.AIR)) {
            sneakValue = true
            holdTimer.reset()
        } else if (holdTimer.hasTimePassed(holdTime.get().toLong()) && limitTimeValue.get()) {
            sneakValue = false
        }
        mc.gameSettings.keyBindSneak.pressed = (mc.gameSettings.isKeyDown(mc.gameSettings.keyBindSneak) || sneakValue)
    }

    override fun onEnable() {
        sneakValue = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindSneak)
        holdTimer.reset()
    }

    override fun onDisable() {
        if (mc.thePlayer == null)
            return

        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindSneak))
            mc.gameSettings.keyBindSneak.pressed = false
    }
}
