/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(name = "GrimFLY", category = ModuleCategory.MOVEMENT, description = "Stevie", cn = "御空秘术")
class TNTFLY : Module() {
    private var tick = 0
    private var s = 0
    var hasReported = false


    override fun onEnable() {
        s = 0
        tick = 0
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!mc.thePlayer!!.onGround) {
            tick++
        } else {
            tick = 0
            s = 0
        }
        if (tick >= 20) {
            s += 1
            tick = 0
            hasReported = false
        }
        if (s >= 1 && !hasReported){
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§d您已飞行了${s}秒")
            hasReported = true
        }
    }
    @EventTarget
    fun onMotion(event: MotionEvent) {

                if (event.eventState.toString() === "PRE") {
                    mc.thePlayer!!.setPositionAndRotation(
                        mc.thePlayer!!.posX + 1000,
                        mc.thePlayer!!.posY,
                        mc.thePlayer!!.posZ,
                        mc.thePlayer!!.rotationYaw,
                        mc.thePlayer!!.rotationPitch
                    );
                } else {
                    mc.thePlayer!!.setPositionAndRotation(
                        mc.thePlayer!!.posX - 1000,
                        mc.thePlayer!!.posY,
                        mc.thePlayer!!.posZ,
                        mc.thePlayer!!.rotationYaw,
                        mc.thePlayer!!.rotationPitch
                    );
                }
    }
}
