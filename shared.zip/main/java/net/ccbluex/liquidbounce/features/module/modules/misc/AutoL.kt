package net.ccbluex.liquidbounce.features.module.modules.misc

import me.sound.SoundPlayer
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue

@ModuleInfo(name = "AutoL", category = ModuleCategory.PIT, description = "CatBounce", cn = "击杀计数")
class AutoL : Module() {
    private val L = BoolValue ("L", true)
    val killmodeValue = ListValue("KillSoundMode", arrayOf("银狼","刃","None"), "银狼")
    val diedmodeValue = ListValue("DiedSoundMode", arrayOf("银狼","刃","甘雨","None"), "银狼")
    private val Volume = FloatValue("Volume", 50f, 0f, 100f)
    private val AutoLmsg = TextValue("AutoLmsg", "@")

    // Target
    var target: IEntityLivingBase? = null
    var kill = 0

    @EventTarget
    fun onAttack(event: AttackEvent) {
        target = event.targetEntity as IEntityLivingBase?
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (target!!.health <= 0.1) {
            kill += 1
            when (killmodeValue.get().toLowerCase()) {
                "银狼" -> SoundPlayer().playSound(SoundPlayer.SoundType.YINLANKILL, Volume.get());
                "刃" -> SoundPlayer().playSound(SoundPlayer.SoundType.LENGKILL, Volume.get());
            }
            if (L.get()) {
                mc.thePlayer!!.sendChatMessage(AutoLmsg.get() + "我已经击杀了" + kill + "人 ")
            }
            target = null
        }
        if (mc.thePlayer!!.isDead || mc.thePlayer!!.health <= 0.1){
            when (diedmodeValue.get().toLowerCase()) {
                "银狼" -> SoundPlayer().playSound(SoundPlayer.SoundType.YINLANDIED, Volume.get());
                "刃" -> SoundPlayer().playSound(SoundPlayer.SoundType.LENGDIED, Volume.get());
                "甘雨" -> SoundPlayer().playSound(SoundPlayer.SoundType.GANYUDIED, Volume.get());
            }
        }
    }

    fun kills() : Int {
        return kill
    }
    override val tag: String?
        get() = "Kill $kill"
}
