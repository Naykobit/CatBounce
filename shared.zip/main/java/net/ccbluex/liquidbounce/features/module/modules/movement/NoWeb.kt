/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "NoWeb", category = ModuleCategory.MOVEMENT, description = "Stevie", cn = "无蜘蛛网")
class NoWeb : Module() {

    private val modeValue = ListValue("Mode", arrayOf("None", "AAC", "LAAC", "Rewi", "Matrix", "Spartan", "AAC5","IntaveTest","FastFall","Test"), "None")
    private var usedTimer = false

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return

        if (usedTimer) {
            mc.timer.timerSpeed = 1F
            usedTimer = false
        }

        if (!thePlayer.isInWeb)
            return


        when (modeValue.get().toLowerCase()) {


            "none" -> thePlayer.isInWeb = false
            "aac" -> {
                thePlayer.jumpMovementFactor = 0.59f

                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    thePlayer.motionY = 0.0
            }
            "laac" -> {
                thePlayer.jumpMovementFactor = if (thePlayer.movementInput.moveStrafe != 0f) 1.0f else 1.21f

                if (!mc.gameSettings.keyBindSneak.isKeyDown)
                    thePlayer.motionY = 0.0

                if (thePlayer.onGround)
                    thePlayer.jump()
            }
            "intavetest" -> {
                if (mc.thePlayer!!.movementInput.moveStrafe == 0.0F && mc.gameSettings.keyBindForward.isKeyDown && mc.thePlayer!!.isCollidedVertically) {
                    mc.thePlayer!!.jumpMovementFactor = 0.74F
                } else {
                    mc.thePlayer!!.jumpMovementFactor = 0.2F
                    mc.thePlayer!!.onGround = true
                }
            }
            "test" -> {
                if (mc.thePlayer!!.ticksExisted % 7 == 0) {
                    mc.thePlayer!!!!.jumpMovementFactor = 0.42f
                }
                if (mc.thePlayer!!.ticksExisted % 7 == 1) {
                    mc.thePlayer!!.jumpMovementFactor = 0.33f
                }
                if (mc.thePlayer!!.ticksExisted % 7 == 2) {
                    mc.thePlayer!!.jumpMovementFactor = 0.08f
                }
            }
            "rewi" -> {
                thePlayer.jumpMovementFactor = 0.42f

                if (thePlayer.onGround)
                    thePlayer.jump()
            }
            "fastfall" -> {
                if (mc.thePlayer!!.onGround && !mc.gameSettings.keyBindJump.isKeyDown) {
                    mc.thePlayer!!.jump();
                }
                if (mc.thePlayer!!.motionY > 0) {
                    mc.thePlayer!!.motionY -= mc.thePlayer!!.motionY * 2
                }
            }
            "spartan" -> {
                MovementUtils.strafe(0.27F)
                mc.timer.timerSpeed = 3.7F
                if (!mc.gameSettings.keyBindSneak.isKeyDown) {
                    mc.thePlayer!!.motionY = 0.0
                }
                if (mc.thePlayer!!.ticksExisted % 2 == 0) {
                    mc.timer.timerSpeed = 1.7F
                }
                if (mc.thePlayer!!.ticksExisted % 40 == 0) {
                    mc.timer.timerSpeed = 3F
                }
                usedTimer = true
            }
            "matrix" -> {
                mc.thePlayer!!.jumpMovementFactor = 0.12425f
                mc.thePlayer!!.motionY = -0.0125
                if (mc.gameSettings.keyBindSneak.isKeyDown) mc.thePlayer!!.motionY = -0.1625

                if (mc.thePlayer!!.ticksExisted % 40 == 0) {
                    mc.timer.timerSpeed = 3.0F
                    usedTimer = true
                }
            }
            "aac5" -> {
                mc.thePlayer!!.jumpMovementFactor = 0.42f

                if (mc.thePlayer!!.onGround) {
                    mc.thePlayer!!.jump()
                }
            }
        }
    }

    override val tag: String?
        get() = modeValue.get()
}
