package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue


@ModuleInfo(name = "AutoSkyWars", category = ModuleCategory.MISC, description = "space.bilibili.com/500398541 作者：菜级玩家 https://www.bilibili.com/read/cv25755876 出处：bilibili", cn = "自动空战")
class AutoSkyWars : Module() {

    private val modeValue = ListValue("mode", arrayOf(
        "firework",
        "fly"
    ), "firework")
    private val X = IntegerValue("posX",0,-100,100)
    private val Y = IntegerValue("posY",10,2,50)
    private val Z = IntegerValue("posZ",0,-100,100)
    private val vanillaSpeedValue = FloatValue("FlySpeed", 4f, 0f, 10f)
    private val Times = IntegerValue("TpTicks",10,0,100)
    private var TPtimes = Times.get()
    private val Debug = BoolValue("Debug", true)
    private var a = 0

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val vanillaSpeed = vanillaSpeedValue.get()
        val thePlayer = mc.thePlayer!!
        val autoSkyWars = LiquidBounce.moduleManager.getModule(AutoSkyWars::class.java) as AutoSkyWars
        if (autoSkyWars.state) {
            if (thePlayer.capabilities.isFlying) {
                when (modeValue.get().toLowerCase()) {
                    "firework" -> {//像烟花一样起飞
                        if (Debug.get()) ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b[修改空岛出生点]")
                        thePlayer.setPositionAndRotation(
                            thePlayer.posX + X.get() / 2,
                            thePlayer.posY + Y.get() / 2,
                            thePlayer.posZ + Z.get() / 2,
                            thePlayer.rotationYaw,
                            thePlayer.rotationPitch
                        )
                    }

                    "fly" -> {//飞行
                        if (TPtimes == 0) {
                            thePlayer.motionY = 0.0
                            thePlayer.motionX = 0.0
                            thePlayer.motionZ = 0.0
                            if (mc.gameSettings.keyBindJump.isKeyDown) thePlayer.motionY += vanillaSpeed
                            if (mc.gameSettings.keyBindSneak.isKeyDown) thePlayer.motionY -= vanillaSpeed
                            MovementUtils.strafe(vanillaSpeed)
                        } else {
                            if (Debug.get()) ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§bFlying")
                            thePlayer.setPositionAndRotation(
                                thePlayer.posX + X.get() / 2,
                                thePlayer.posY + Y.get() / 2,
                                thePlayer.posZ + Z.get() / 2,
                                thePlayer.rotationYaw,
                                thePlayer.rotationPitch
                            )
                            TPtimes -= 1
                        }
                    }
                }
            } else {
                val thePlayer = mc.thePlayer ?: return
                thePlayer.capabilities.isFlying = false
                mc.timer.timerSpeed = 1f
                thePlayer.speedInAir = 0.02f
                TPtimes = Times.get()
            }
        }
    }

    override fun handleEvents() = true
    override val tag: String
        get() = modeValue.get()
    override fun onDisable() {
        val thePlayer = mc.thePlayer!!
        thePlayer.capabilities.isFlying = false
        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindForward))
            mc.gameSettings.keyBindForward.pressed = false
    }
}