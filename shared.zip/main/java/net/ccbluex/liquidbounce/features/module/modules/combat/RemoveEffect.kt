/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue

@ModuleInfo(name = "RemoveEffect", category = ModuleCategory.COMBAT, description = "1", cn = "移除药水效果")
class RemoveEffect : Module() {

    private val shouldRemoveSlowness = BoolValue("Slowness", false)
    private val shouldRemoveMiningFatigue = BoolValue("MiningFatigue", false)
    private val shouldRemoveBlindness = BoolValue("Blindness", false)
    private val shouldRemoveWeakness = BoolValue("Weakness", false)
    private val shouldRemoveWither = BoolValue("Wither", false)
    private val shouldRemovePoison = BoolValue("Poison", false)
    private val shouldRemoveHARM = BoolValue("Harm", false)
    private val shouldRemoveHUNGER = BoolValue("Hunger", false)



    override fun onEnable() {}

    @EventTarget(ignoreCondition = true)
    fun onUpdate(event: UpdateEvent?) {

        if (mc.thePlayer != null) {

            val effectIdsToRemove = mutableListOf<Int>()
            if (shouldRemoveSlowness.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.MOVE_SLOWDOWN).id)
            if (shouldRemoveMiningFatigue.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.DIG_SLOWDOWN).id)
            if (shouldRemoveBlindness.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.BLINDNESS).id)
            if (shouldRemoveWeakness.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.WEAKNESS).id)
            if (shouldRemoveWither.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.WITHER).id)
            if (shouldRemovePoison.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.POISON).id)
            if (shouldRemoveHARM.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.HARM).id)
            if (shouldRemoveHUNGER.get()) effectIdsToRemove.add(classProvider.getPotionEnum(PotionType.HUNGER).id)


            for (effectId in effectIdsToRemove) {
                mc.thePlayer!!.removePotionEffectClient(effectId)
            }
        }
    }
}
