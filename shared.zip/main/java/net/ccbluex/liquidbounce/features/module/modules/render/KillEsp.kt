
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.client.gui.ScaledResolution
import org.lwjgl.opengl.GL11


@ModuleInfo(name = "KillEsp", description = "catbounce.", category = ModuleCategory.RENDER, cn = "简易血显")
class KillEsp : Module() {

    private val showTargetValue = BoolValue("ShowTarget", true)
    private lateinit var killAura: KillAura
    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        val currentTarget = killAura.currentTarget
        if (showTargetValue.get()) {
            val sr2 = ScaledResolution(mc2)
            if (currentTarget != null) {
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f)
                Fonts.font30.drawStringWithShadow(currentTarget!!.name!!,
                    (sr2.scaledWidth / 2 - Fonts.font30.getStringWidth(currentTarget!!.name!!) / 2).toFloat().toInt(),
                    (sr2.scaledHeight / 2 - 40).toFloat().toInt(), 16777215)
                mc.textureManager.bindTexture((("textures/gui/icons.png") as IResourceLocation?)!!)
                var i2 = 0
                var i3 = 0
                while (i2 < currentTarget!!.maxHealth / 2) {
                    mc2.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - currentTarget!!.maxHealth / 2.0f * 10.0f / 2.0f + (i2 * 10)).toInt(), (sr2.scaledHeight / 2 - 20), 16, 0, 9, 9);
                    ++i2
                }
                i2 = 0
                while (i2 < currentTarget!!.health / 2.0){
                    mc2.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - currentTarget!!.maxHealth / 2.0f * 10.0f / 2.0f + (i2 * 10)).toInt(), (sr2.scaledHeight / 2 - 20), 52, 0, 9, 9);
                    ++i2
                }
                while (i3 < 20 / 2.0f) {
                    mc2.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - currentTarget!!.maxHealth / 2.0f * 10.0f / 2.0f + (i3 * 10)).toInt(), (sr2.scaledHeight / 2 - 30), 16, 9, 9, 9);
                    ++i3;
                }
                i3 = 0;
                while (i3 < currentTarget!!.totalArmorValue / 2.0f) {
                    mc2.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - currentTarget!!.maxHealth / 2.0f * 10.0f / 2.0f + (i3 * 10)).toInt(), (sr2.scaledHeight / 2 - 30), 34, 9, 9, 9);
                    ++i3;
                }
            }
        }
    }
}
