/*
 * FDP CLIENT 
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue

@ModuleInfo(name = "TickBase", category = ModuleCategory.COMBAT, cn = "攻击冲刺",description = "fdp")
class TickBase : Module() {

    private var ticks = 0
    private val Debug = BoolValue("debug", false)
    val ticksAmount = IntegerValue("BoostTicks", 10, 3, 20)
    val BoostAmount = FloatValue("BoostTimer", 10f, 1f, 50f)
    val ChargeAmount = FloatValue("ChargeTimer", 0.11f, 0.05f, 1f)

    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (classProvider.isEntityLivingBase(event.targetEntity) && ticks == 0) {
            ticks = ticksAmount.get()
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dAttack")
            }
        }
    }

    override fun onEnable() {
        mc.timer.timerSpeed = 1f
        if (Debug.get()) {
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d复原")
        }
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1f
        if (Debug.get()) {
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d复原")
        }
    }


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (ticks == ticksAmount.get()) {
            mc.timer.timerSpeed = ChargeAmount.get()
            ticks --
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dtick==CA")
            }
        } else if (ticks > 1) {
            mc.timer.timerSpeed = BoostAmount.get()
            ticks --
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dtick>1")
            }
        } else if (ticks == 1) {
            mc.timer.timerSpeed = 1f
            ticks --
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dtick==1")
            }
        }
    }


}
