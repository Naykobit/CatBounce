package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "LegitAutoBlock", description = "CatBounce",category = ModuleCategory.COMBAT, cn = "合法自动防砍")
class LegitAutoBlock : Module() {
    private var blockRange = FloatValue("StartBlockRange", 2.99f, 0f, 6f)
    private var sblockRange = FloatValue("StopBlockRange", 1.75f, 0f, 6f)
    private var extraRange = FloatValue("CooldownRange", 3.05f, 0f, 5f)


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        val objectMouseOver = mc.objectMouseOver
        for (entity: IEntity in mc.theWorld!!.loadedEntityList) {
            if (mc.thePlayer!!.onGround) {
                if (objectMouseOver != null
                    && EntityUtils.isSelected(objectMouseOver.entityHit, true)
                    && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item) && entity.hurtResistantTime != 0
                    && entity.posY.toInt() >= mc2.player.posY.toInt()
                ) {
                    if (mc.thePlayer!!.getDistanceToEntity(entity) < blockRange.get() && mc.thePlayer!!.getDistanceToEntity(entity) > sblockRange.get()) {
                        mc.gameSettings.keyBindUseItem.pressed = true
                    }else if (mc.thePlayer!!.getDistanceToEntity(entity) <= extraRange.get()){
                        mc.gameSettings.keyBindUseItem.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindUseItem)
                    }
                } else {
                    mc.gameSettings.keyBindUseItem.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindUseItem)
                }
            } else {
                mc.gameSettings.keyBindUseItem.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindUseItem)
            }
        }
    }
}