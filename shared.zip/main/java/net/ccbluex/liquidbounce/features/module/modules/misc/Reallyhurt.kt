package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.features.module.modules.combat.Safeauramode
import net.ccbluex.liquidbounce.features.module.modules.exploit.NoC0B
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.server.SPacketChat
import java.util.regex.Pattern
/*
    //Made By 小猫很可爱 3414576738
   //外部群：553849936
   //欲商业使用请联系Dev
   //有什么可以改进的地方请联系我 ，我会优化
   //不联系直接用的改成自己东西的给我死
   //别给我去掉它
*/
@ModuleInfo(name = "Reallyhurt", category =ModuleCategory.MISC, description = "CatBounce，外部群：553849936,别给我改", cn = "空刀检测")
class Reallyhurt : Module() {

    private val nohurtValue = IntegerValue("nohurtValue", 3, 1, 100)
    private val saferangeValue = FloatValue("saferangeValue", 3f, 3f, 6f)
    var normalgroundrangeValue = FloatValue("normalgroundrangeValue", 3f, 3f, 6f)
    var normalairrangeValue = FloatValue("normalairrangeValue", 3f, 3f, 6f)
    var safeValue = FloatValue("maxsafeValue", 3f, 3f, 6f)
    private val Debug = BoolValue("Debug", true)
    private val Heal = BoolValue("Heal", true)
    private val faceHeal = BoolValue("faceHeal", true)
    private val faceentidyHeal = BoolValue("faceentidyHeal", true)
    private val autorange = BoolValue("autorange", true)
    private val autohub = BoolValue("autohub", true)
    private val autosafe = BoolValue("autosafe", true)
    private val autodis = BoolValue("autodis", true)
    private var hit = false
    private var change = false
    private var rest = false
    private var b = 0
    private var health: Float = 20F
    private var facehealth: Float = 20F
    private var health2: Float = 20F
    private var ticks = 0
    private var cooldown = 0


    override fun onEnable() {
        hit = false
        rest = false
        cooldown = 0
        b = 0
    }

    @EventTarget
    fun onAttack(event: AttackEvent) {
        hit = true
        cooldown = 0
    }

    @EventTarget
    fun onRender(event: Render3DEvent) {
        val objectMouseOver = mc.objectMouseOver

        if (objectMouseOver != null &&
            EntityUtils.isSelected(objectMouseOver.entityHit, true)){
            val entityHit = objectMouseOver.entityHit
            if (entityHit is IEntityLivingBase) {
                health2 = entityHit.health
            }
            }
    }


    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if ((packet is SPacketChat) && !packet.chatComponent.unformattedText.contains(":") && (packet.chatComponent.unformattedText.startsWith(
                "起床战争"
            ) || packet.chatComponent.unformattedText.startsWith("[起床战争") || packet.chatComponent.unformattedText.startsWith("花雨庭"))
        ) {
            val chat = packet.chatComponent.unformattedText
            val matcher = Pattern.compile("游戏开始").matcher(chat)
            val matcher2 = Pattern.compile("恭喜").matcher(chat)
            val matcher3 = Pattern.compile("加入游戏").matcher(chat)
            if (matcher.find() || matcher2.find() || matcher3.find()) {
                b = 0
                hit = false
                rest = false
                if (Debug.get()) {
                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d空刀检测还原")
                }
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        ticks += 1
        cooldown += 1
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura?
        val safeauramode = LiquidBounce.moduleManager[Safeauramode::class.java] as Safeauramode?
        val noc0b = LiquidBounce.moduleManager[NoC0B::class.java] as NoC0B?
        if (!aura!!.state || aura.target == null) hit = false
        for (entity in mc.theWorld!!.loadedEntityList) {
                val entityLiving = entity.asEntityLivingBase()
                if (!hit) health = entityLiving.health
        }
        if(RotationUtils.isFaced(aura.target, 0.05) && faceHeal.get() && !hit) facehealth = aura.target!!.health
            if ((hit && aura.target!!.hurtTime == 0 && aura.target!!.hurtResistantTime == 0 ) || (Heal.get() && hit && aura.target!!.health == health ) ||
                (hit && faceHeal.get() && aura.target!!.health == facehealth) || (hit && faceentidyHeal.get() && aura.target!!.health == health2)){
                b += 1
                hit = false
                if (autorange.get() && ticks > 0) {
                    safeauramode!!.normalgroundrangeValue.set(saferangeValue.get())
                    safeauramode!!.normalairrangeValue.set(saferangeValue.get())
                    ticks = 0
                    change = true
                    if (Debug.get()) {
                        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d检测到空刀，已自动切换至安全距离${saferangeValue.get()}")
                    }
                }
                if (autodis.get() && ticks > 0) {
                    ticks = 0
                    if (noc0b != null) {
                        noc0b.state = false
                    }

                    aura.state = false
                    if (Debug.get()) {
                        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d检测到空刀，已自动关闭杀戮")
                    }
                }
                if (Debug.get()) {
                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d空刀数:$b!!!")
                }
            } else if(hit){
                hit = false
                if (autorange.get() && ticks > 0 &&  aura.groundRangeValue != normalgroundrangeValue) {
                    change = true
                    ticks = 0
                }
            }

        if (ticks == 40 && autorange.get() && change) {
            safeauramode!!.normalgroundrangeValue.set(normalgroundrangeValue.get())
            safeauramode!!.normalairrangeValue.set(normalairrangeValue.get())
                change = false
                if (Debug.get()) {
                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d单位时间内未检出空刀，已自动切换至正常距离")
                }
            }
        if (b >= nohurtValue.get() && autohub.get()){
            mc.thePlayer!!.sendChatMessage("/hub")
            b = 0
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d空刀数达到上限，您已自动hub")
            }
        }
        if (b >= nohurtValue.get() && autosafe.get() && !rest){
            safeauramode!!.normalgroundrangeValue.set(safeValue.get())
            safeauramode!!.normalairrangeValue.set(safeValue.get())
            rest = true
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d空刀数达到上限，您的距离已设为最安全范围")
            }
        }
    }
}