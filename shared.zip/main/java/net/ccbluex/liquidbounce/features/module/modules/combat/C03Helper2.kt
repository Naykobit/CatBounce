/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.TNTFLY
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(name = "C03Helper2", description = "catbounce", category = ModuleCategory.COMBAT, cn = "C03助手2")
class C03Helper2 : Module() {

    private lateinit var tntfly: TNTFLY
    private var a = 0

    override fun onEnable() {
        tntfly = LiquidBounce.moduleManager.getModule(TNTFLY::class.java) as TNTFLY
        a = 0
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        a += 1
        if (a == 21){
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b你现在可以移动了！")
            val c03Helper2 = LiquidBounce.moduleManager.getModule(C03Helper2::class.java) as C03Helper2
            c03Helper2.state = false
            tntfly.state = false
        }
    }

}