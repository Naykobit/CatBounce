/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode

class LegitSpeed2 : SpeedMode("LegitSpeed2") {
    override fun onMotion(event: MotionEvent) {
        if (mc.thePlayer!!.isInWater) return
        if (mc.thePlayer!!.onGround) {
            mc.gameSettings.keyBindJump.pressed = true
        } else mc.gameSettings.keyBindJump.pressed = false
    }

    override fun onUpdate() {
    }

    override fun onDisable() {
        mc.gameSettings.keyBindJump.pressed = false
    }
    override fun onMove(event: MoveEvent) {}
}