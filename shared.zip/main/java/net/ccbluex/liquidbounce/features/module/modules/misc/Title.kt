package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.TextValue

@ModuleInfo(name = "Title", category = ModuleCategory.MISC, description = "CatBounce", cn = "标题设置")
class Title : Module(){
    private val fakeNameValue = TextValue("SetTitle", "CatBounce")
    private val CopywritingValue = TextValue("Copywriting", "1.0.3.3")
    private val yiyan = TextValue("yiyan", "1.0.3.3")
    private var S = 0
    private var HM = 0
    private var M = 0
    private var H = 0

    @EventTarget
    fun onUpdate(event: UpdateEvent){
        org.lwjgl.opengl.Display.setTitle(fakeNameValue.get()+ "   "+CopywritingValue.get())
    }
}