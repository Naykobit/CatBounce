package net.ccbluex.liquidbounce.features.module.modules.misc

import me.sound.SoundPlayer
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.GrimVelocity4
import net.ccbluex.liquidbounce.features.module.modules.movement.AutoFLY
import net.ccbluex.liquidbounce.features.module.modules.movement.TNTFLY
import net.ccbluex.liquidbounce.features.module.modules.player.Blink
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.server.SPacketChat
import net.minecraft.network.play.server.SPacketPlayerPosLook
import java.util.regex.Pattern

@ModuleInfo(name = "Nolagban", category =ModuleCategory.MISC, description = "CatBounce", cn = "没有Lag封禁")
class Nolagban : Module() {

    private val FlagValue = IntegerValue("FlagValue", 10, 1, 100)
    private val Debug = BoolValue("Debug", true)
    private val autohub = BoolValue("Autohub", true)
    private var a = 0
    private var b = 0
    private var c = 0
    private var d = 0
    var isvoid = 0

    override fun onEnable() {
        a = 0
        b = 0
        c = 0
        d = 0
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val  e = event.packet.unwrap()
        val packet = event.packet.unwrap()
        if ((packet is SPacketChat) && !packet.chatComponent.unformattedText.contains(":")) {
            val chat = packet.chatComponent.unformattedText
            val matcher = Pattern.compile("游戏开始").matcher(chat)
            val matcher2 = Pattern.compile("恭喜").matcher(chat)
            val matcher3 = Pattern.compile("加入了游戏").matcher(chat)
            val matcher4 = Pattern.compile("玩家${mc.thePlayer!!.name}在本局游戏中行为异常").matcher(chat)
            val matcher5 = Pattern.compile("正在进行匹配").matcher(chat)
            val matcher6 = Pattern.compile("已为你自动开启").matcher(chat)
            val matcher7 = Pattern.compile("开始倒计时").matcher(chat)
            if (matcher.find() || matcher2.find() || matcher3.find() || matcher5.find() || matcher6.find() || matcher7.find()) {
                b = 0
                a = 0
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dFlag清除")
            }
            }
            if (matcher4.find()) {
                mc.thePlayer!!.sendChatMessage("/hub")
                b = 0
                a = 0
                if (Debug.get()) {
                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d检测到封禁信息，已自动退出游戏")
                }
                SoundPlayer().playSound(SoundPlayer.SoundType.LUOCHASIHAO, 50f);
            }
        }
        val Blink = LiquidBounce.moduleManager[Blink::class.java] as Blink
        val tntfly = LiquidBounce.moduleManager[TNTFLY::class.java] as TNTFLY
        val autoFLY = LiquidBounce.moduleManager[AutoFLY::class.java] as AutoFLY
        if ((e is SPacketPlayerPosLook) && b >= 20 && !Blink.state
                 && c <= 8 && !tntfly.state && !autoFLY.state){
            a += 1

            d = 1
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dFlag:$a")
            }
        }
    }

    private fun checkVoid(): Boolean {
        var i = (-(mc.thePlayer!!.posY-1.4857625)).toInt()
        var dangerous = true
        while (i <= 0) {
            dangerous = mc.theWorld!!.getCollisionBoxes(mc.thePlayer!!.entityBoundingBox.offset(mc.thePlayer!!.motionX * 1.4, i.toDouble(), mc.thePlayer!!.motionZ * 1.4)).isEmpty()
            i++
            if (!dangerous) break
        }
        return dangerous
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (checkVoid()) {
            isvoid++
        }else{
            isvoid =0
        }
        if(isvoid > 30 ){
            d = 29
        }
        b += 1
        if (d >0){
            d++
            if (d > 30) {
                d=0
            }
        }
        if (!mc.thePlayer!!.onGround) c += 1
        if (mc.thePlayer!!.onGround) c = 0
        if (autohub.get() && a == FlagValue.get()){
            mc.thePlayer!!.sendChatMessage("/hub")
            a = 0
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dFlag清除")
            }
        }
        if (mc.thePlayer!!.health <= 0f || mc.thePlayer!!.isDead ) {
            b = -100
        }
    }
}