/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class GrimHop : SpeedMode("GrimHop") {
    var a = 0
    override fun onMotion(event: MotionEvent) {
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1f
        mc.thePlayer!!.speedInAir = 0.02f
    }

    override fun onEnable() {
        a = 0
    }
    @EventTarget
    fun onJump(event: JumpEvent?) {
        if (mc.thePlayer != null || MovementUtils.isMoving) {
            var boost: Float
            if (mc.thePlayer!!.isPotionActive(classProvider.getPotionEnum(PotionType.MOVE_SPEED)) && mc.thePlayer!!.getActivePotionEffect(classProvider.getPotionEnum(PotionType.MOVE_SPEED))!!.amplifier != 2) {
                mc.thePlayer!!.motionX *= (0.7 * (mc.thePlayer!!.getActivePotionEffect(
                    classProvider.getPotionEnum(PotionType.MOVE_SPEED))!!.amplifier + 1))
                mc.thePlayer!!.motionZ *= (0.7 * (mc.thePlayer!!.getActivePotionEffect(
                    classProvider.getPotionEnum(PotionType.MOVE_SPEED))!!.amplifier + 1))
            }
        }
    }
    override fun onUpdate() {
    }
    override fun onMove(event: MoveEvent) {}
}