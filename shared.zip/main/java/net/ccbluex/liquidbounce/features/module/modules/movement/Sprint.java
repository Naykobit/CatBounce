/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.features.module.modules.world.ScaHelperNew;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.Rotation;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

import static me.utils.player.PlayerUtil.isMoving;

@ModuleInfo(name = "Sprint", description = "Automatically sprints all the time.", category = ModuleCategory.MOVEMENT, cn = "保持疾跑")
public class Sprint extends Module {

    public final BoolValue allDirectionsValue = new BoolValue("AllDirections", true);
    public final BoolValue airValue = new BoolValue("JumpDirections", true);
    public final BoolValue blindnessValue = new BoolValue("Blindness", true);
    public final BoolValue strafenosprint = new BoolValue("strafenosprint", true);

    public final BoolValue rotateValue = new BoolValue("Rotate", true);

    public final BoolValue sneakValue = new BoolValue("Sneak", true);
    public final BoolValue foodValue = new BoolValue("Food", true);

    public final BoolValue nofoodValue = new BoolValue("noFood", true);
    public final BoolValue checkServerSide = new BoolValue("CheckServerSide", false);
    public final BoolValue checkServerSideGround = new BoolValue("CheckServerSideOnlyGround", false);

    private boolean needStop = false;
    int a = 0;
    @EventTarget
    public void onUpdate(final UpdateEvent event) {
        KillAura aura = (KillAura) LiquidBounce.moduleManager.getModule(KillAura.class);
        Strafe strafe = (Strafe) LiquidBounce.moduleManager.getModule(Strafe.class);
        TargetStrafelb targetStrafelb = (TargetStrafelb) LiquidBounce.moduleManager.getModule(TargetStrafelb.class);
        EntitySpeed espeed = (EntitySpeed) LiquidBounce.moduleManager.getModule(EntitySpeed.class);
        ScaHelperNew scaHelperNew = (ScaHelperNew) LiquidBounce.moduleManager.getModule(ScaHelperNew.class);
        if ((nofoodValue.get() && classProvider.isItemFood(mc.getThePlayer().getHeldItem().getItem())) || !MovementUtils.isMoving()  ||  (targetStrafelb.getState() && !targetStrafelb.getSprint()) || (espeed.getStrgo() && strafenosprint.get() && strafe.getState() )|| !aura.getSprinting() || (mc.getThePlayer().isSneaking() && !sneakValue.get()) ||
                (blindnessValue.get() && mc.getThePlayer().isPotionActive(classProvider.getPotionEnum(PotionType.BLINDNESS))) ||
                (foodValue.get() && !(mc.getThePlayer().getFoodStats().getFoodLevel() > 6.0F || mc.getThePlayer().getCapabilities().getAllowFlying()))
                || (checkServerSide.get() && (mc.getThePlayer().getOnGround() || !checkServerSideGround.get())
                && !allDirectionsValue.get() && RotationUtils.targetRotation != null &&
                RotationUtils.getRotationDifference(new Rotation(mc.getThePlayer().getRotationYaw(), mc.getThePlayer().getRotationPitch())) > 30)) {
            mc.getThePlayer().setSprinting(false);
            return;
        }

        if(mc.getGameSettings().getKeyBindForward().isKeyDown() || mc.getGameSettings().getKeyBindLeft().isKeyDown()
                || mc.getGameSettings().getKeyBindRight().isKeyDown() || mc.getGameSettings().getKeyBindBack().isKeyDown()
        ){
            a += 1;
        }else {
            a = 0;
        }
        if (RotationUtils.getRotationDifference(
                new Rotation(MovementUtils.getMovingYaw(), mc.getThePlayer().getRotationPitch()), new Rotation(mc.getThePlayer().getRotationYaw(), mc.getThePlayer().getRotationPitch())) > 30) {
            if(rotateValue.get() && a > 5){
                RotationUtils.setTargetRotation(new Rotation(MovementUtils.getMovingYaw(), mc.getThePlayer().getRotationPitch()), 2);
            }
        }

        if (allDirectionsValue.get() || mc.getThePlayer().getMovementInput().getMoveForward() >= 0.8F || espeed.getSprint() || (mc.getThePlayer().isSneaking() && sneakValue.get()))
            mc.getThePlayer().setSprinting(true);


    }
}
