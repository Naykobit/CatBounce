/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.exploit.NoC03
import net.ccbluex.liquidbounce.features.module.modules.movement.TNTFLY
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(name = "C03Helper", description = "catbounce", category = ModuleCategory.COMBAT, cn = "C03助手")
class C03Helper : Module() {
    private lateinit var killAura: KillAura2
    private lateinit var noC03: NoC03
    private lateinit var velocity: Velocity
    private lateinit var tntfly: TNTFLY
    private lateinit var c03Helper2: C03Helper2

    override fun onEnable() {
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b已开启NoC03，请确保你打到一个目标的第一刀距离在3.3格以内，关闭时请注意不要受到伤害")
        killAura = LiquidBounce.moduleManager.getModule(KillAura2::class.java) as KillAura2
        noC03 = LiquidBounce.moduleManager.getModule(NoC03::class.java) as NoC03
        velocity = LiquidBounce.moduleManager.getModule(Velocity::class.java) as Velocity
        tntfly = LiquidBounce.moduleManager.getModule(TNTFLY::class.java) as TNTFLY
        c03Helper2 = LiquidBounce.moduleManager.getModule(C03Helper2::class.java) as C03Helper2
        killAura.rangeValue.set(3.3)
        noC03.state = true
        velocity.state = true
        killAura.state = true
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (killAura.target!!.hurtTime > 0) {
            killAura.rangeValue.set(6.0)
        }
        mc.gameSettings.keyBindForward.pressed = false
        mc.gameSettings.keyBindLeft.pressed = false
        mc.gameSettings.keyBindBack.pressed = false
        mc.gameSettings.keyBindRight.pressed = false
    }
    override fun onDisable() {
        noC03.state = false
        velocity.state = false
        killAura.state = false
        tntfly.state = true
        c03Helper2.state = true
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b已关闭NoC03，请在接下来的1s内不要移动")
    }
}