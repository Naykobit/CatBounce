package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.server.SPacketPlayerPosLook

@ModuleInfo(name = "BowFly", description = ".", category = ModuleCategory.MOVEMENT, cn = "弓箭飞行")
class BowFly: Module() {
    private val debugValue = BoolValue("Debug", true)
    private val autoDisableValue = BoolValue("AutoDisable", true)

    private val msTimer = MSTimer()

    fun debug(str: String) {
        if (debugValue.get()) ClientUtils.displayChatMessage("§7[§bBowFly§7] §r${str}")
    }

    override fun onEnable() {
        debug("Fly准备！请于Fly模块中设置参数！")
        LiquidBounce.moduleManager.getModule(Fly::class.java).array = true
        msTimer.reset()
    }

    override fun onDisable() {
        val fly = LiquidBounce.moduleManager.getModule(Fly::class.java)

        if (fly.state) {
            fly.state = false
        }
        fly.array = true
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val fly = LiquidBounce.moduleManager.getModule(Fly::class.java)
        if (msTimer.hasTimePassed(1000L) && !fly.state) {
            msTimer.reset()
            debug("需要受到伤害！")
        }
        if (mc.thePlayer!!.hurtTime > 0) {
            fly.state = true
            debug("Boosting!")
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()

        if (packet is SPacketPlayerPosLook) {
            val fly = LiquidBounce.moduleManager.getModule(Fly::class.java)
            if (autoDisableValue.get() && fly.state) {
                fly.state = false
                debug("LagBack!")
                this.state = false
            }
        }
    }
}