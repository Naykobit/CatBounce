/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class IntaveHop2 : SpeedMode("IntaveHop2") {
    override fun onMotion(event: MotionEvent) {}
    override fun onEnable() {}
    override fun onUpdate() {
        mc.gameSettings.keyBindJump.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump)
        if (MovementUtils.isMoving) {
            if (mc.thePlayer!!.onGround) {
                mc.gameSettings.keyBindJump.pressed = false
                mc.timer.timerSpeed = 1.0f
                mc.thePlayer!!.jump()
            }

            if (mc.thePlayer!!.motionY > 0.003) {
                mc.thePlayer!!.motionX *= 1.0014
                mc.thePlayer!!.motionZ *= 1.0016
                mc.timer.timerSpeed = 1.07f
            }
        }
    }
    override fun onMove(event: MoveEvent) {}
}