/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement;

import me.utils.PacketUtils;
import net.ccbluex.liquidbounce.api.enums.EnumFacingType;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketHeldItemChange;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayer;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;

import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.MovementUtils;

import net.ccbluex.liquidbounce.utils.render.RenderUtils;

import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;

import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;

import java.awt.*;

@ModuleInfo(name = "BowJump", description = "114514", category = ModuleCategory.MOVEMENT, cn = "弓箭跳跃")
public class BowJump extends Module {

    private final BoolValue hypixelBypassValue = new BoolValue("hypixelBypass", true);
    private final ListValue modeValue = new ListValue("BoostMode", new String[] {"Strafe","SpeedInAir"}, "Strafe");
    private final FloatValue speedInAirBoostValue = new FloatValue("SpeedInAir", 0.5F, 0.02F, 1F);
    private final FloatValue boostValue = new FloatValue("Boost", 4.25F, 0F, 10F);
    private final FloatValue heightValue = new FloatValue("Height", 0.42F, 0F, 10F);
    private final FloatValue timerValue = new FloatValue("Timer", 1F, 0.1F, 10F);
    private final IntegerValue delayBeforeLaunch = new IntegerValue("DelayBeforeArrowLaunch", 1, 1, 20);

    private final BoolValue autoDisable = new BoolValue("AutoDisable", true);
    private final BoolValue renderValue = new BoolValue("RenderStatus", true);

    private int bowState = 0;
    private long lastPlayerTick = 0;


    private int lastSlot = -1;

    public void onEnable() {
        if (mc.getThePlayer() == null) return;
        bowState = 0;
        lastPlayerTick = -1;
        lastSlot = mc.getThePlayer().getInventory().getCurrentItem();

        MovementUtils.INSTANCE.strafe(0.0f);
        mc2.player.onGround = false ;
        mc2.player.jumpMovementFactor = 0.0f;
//        mc.getThePlayer().getJumpMovementFactor() ;
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        if (mc2.player.onGround && bowState < 3)
            event.cancelEvent();
            event.zero();
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (classProvider.isCPacketHeldItemChange(event.getPacket())){
            ICPacketHeldItemChange c09 = (ICPacketHeldItemChange) event.getPacket();
            lastSlot = c09.getSlotId();
            event.cancelEvent();
        }

        if (classProvider.isCPacketPlayer(event.getPacket())){
//        if (event.getPacket() instanceof CPacketPlayer) {
            ICPacketPlayer c03 = (ICPacketPlayer) event.getPacket();

//            if (bowState < 3) c03.setMoving(false);
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        mc.getTimer().setTimerSpeed(1f);

        boolean forceDisable = false;
        switch (bowState) {
        case 0:
            int slot = getBowSlot();
            if (slot < 0 || !mc2.player.inventory.hasItemStack(Items.ARROW.getDefaultInstance())) {
                forceDisable = true;
                bowState = 5;
                break; // nothing to shoot
            } else if (lastPlayerTick == -1) {
                ItemStack stack = mc2.player.inventoryContainer.getSlot(slot + 36).getStack();

                if (lastSlot != slot)  mc.getNetHandler().addToSendQueue(classProvider.createCPacketHeldItemChange(slot));
                mc.getNetHandler().addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(( new WBlockPos(-1, -1, -1)), 255, mc.getThePlayer().getInventoryContainer().getSlot(slot + 36).getStack(), 0, 0, 0));
//                PacketUtils.sendPacketNoEvent(new CPacketPlayerBlockPlacement(new WBlockPos(-1, -1, -1), 255, mc.thePlayer.inventoryContainer.getSlot(slot + 36).getStack(), 0, 0, 0));

                lastPlayerTick = mc2.player.ticksExisted;
                bowState = 1;
            }
            break;
        case 1:
            int reSlot = getBowSlot();
            if (mc2.player.ticksExisted - lastPlayerTick > delayBeforeLaunch.get()) {
                mc.getNetHandler().addToSendQueue(classProvider.createCPacketPlayerLook(mc.getThePlayer().getRotationYaw(), -90, mc2.player.onGround));
//                PacketUtils.sendPacketNoEvent(new CPacketPlayer.C05PacketPlayerLook(mc.thePlayer.rotationYaw, -90, mc.thePlayer.onGround));
                mc.getNetHandler().addToSendQueue(classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.Companion.getORIGIN(), classProvider.getEnumFacing(EnumFacingType.DOWN) ));
//                PacketUtils.sendPacketNoEvent(new CPacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));

                if (lastSlot != reSlot)  mc.getNetHandler().addToSendQueue(classProvider.createCPacketHeldItemChange(lastSlot));
                bowState = 2;
            }
            break;
        case 2:
            if (mc2.player.hurtTime > 0)
                bowState = 3;
            break;
        case 3:
            if (hypixelBypassValue.get()) {
                if (mc2.player.hurtTime >= 8) {
                    mc2.player.motionY = 0.58;
                    mc2.player.jump();
                }
                if (mc2.player.hurtTime == 8) {
                    MovementUtils.INSTANCE.strafe(0.72f);
                }

                if (mc2.player.hurtTime == 7) {
                    mc2.player.motionY += 0.03;
                }

                if (mc2.player.hurtTime <= 6) {
                    mc2.player.motionY += 0.015;
                }
                mc.getTimer().setTimerSpeed(timerValue.get());
                if (mc2.player.onGround && mc2.player.ticksExisted - lastPlayerTick >= 1)
                    bowState = 5;
            } else {
                switch (modeValue.get()) {
                    case "Strafe": {
                        MovementUtils.INSTANCE.strafe(boostValue.get());
                        break;
                    }
                    case "SpeedInAir":{
                        mc2.player.speedInAir = speedInAirBoostValue.getValue();
                        mc2.player.jump();
                    }
                }
                mc2.player.motionY = heightValue.get();
                bowState = 4;
                lastPlayerTick = mc2.player.ticksExisted;
                break;
            }
        case 4:
            mc.getTimer().setTimerSpeed(timerValue.get());
            if (mc2.player.onGround && mc2.player.ticksExisted - lastPlayerTick >= 1)
                bowState = 5;
            break;
        }

        if (bowState < 3) {
            mc2.player.movementInput.moveForward = 0F;
            mc2.player.movementInput.moveStrafe = 0F;
        }

        if (bowState == 5 && (autoDisable.get() || forceDisable)) 
            this.setState(false);
    }

    @EventTarget
    public void onWorld(WorldEvent event) {
        this.setState(false); //prevent weird things
    }

    public void onDisable(){
        mc.getTimer().setTimerSpeed(1.0f);
        mc2.player.speedInAir = 0.02F;
    }

    private int getBowSlot() {
        for(int i = 36; i < 45; ++i) {
            ItemStack stack = mc2.player.inventoryContainer.getSlot(i).getStack();
            if (stack != null && stack.getItem() instanceof ItemBow) {
                return i - 36;
            }
        }
        return -1;
    }

    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        if (!renderValue.get()) return;
        ScaledResolution scaledRes = new ScaledResolution(mc2);
            
        float width = (float) bowState / 5F * 60F;

        Fonts.font40.drawCenteredString(getBowStatus(), scaledRes.getScaledWidth() / 2F, scaledRes.getScaledHeight() / 2F + 14F, -1, true);
        RenderUtils.drawRect(scaledRes.getScaledWidth() / 2F - 31F, scaledRes.getScaledHeight() / 2F + 25F, scaledRes.getScaledWidth() / 2F + 31F, scaledRes.getScaledHeight() / 2F + 29F, 0xA0000000);
        RenderUtils.drawRect(scaledRes.getScaledWidth() / 2F - 30F, scaledRes.getScaledHeight() / 2F + 26F, scaledRes.getScaledWidth() / 2F - 30F + width, scaledRes.getScaledHeight() / 2F + 28F, getStatusColor());
        
    }

    public String getBowStatus() {
        switch (bowState) {
            case 0:
            return "Idle...";
            case 1:
            return "Preparing...";
            case 2:
            return "Waiting for damage...";
            case 3:
            case 4:
            return "Boost!";
            default:
            return "Task completed.";
        }
    }

    public Color getStatusColor() {
        switch (bowState) {
            case 0:
            return new Color(21, 21, 21);
            case 1:
            return new Color(48, 48, 48);
            case 2:
            return Color.yellow;
            case 3:
            case 4:
            return Color.green;
            default:
            return new Color(0, 111, 255);
        }
    }
}
