
package net.ccbluex.liquidbounce.features.module.modules.movement

import me.manager.ColorManager
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.features.module.modules.combat.SuperKnockback
import net.ccbluex.liquidbounce.features.module.modules.combat.Wtap
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import org.lwjgl.opengl.GL11
import java.awt.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt


@ModuleInfo(name = "GrimStrafe", description = "catbounce.", category = ModuleCategory.MOVEMENT, cn = "Grim转圈圈")
class GrimStrafe : Module() {
    val radius = FloatValue("Radius", 2.0f, 0.1f, 4.0f)
    val extrarange = FloatValue("extrarange", 0.4f, 0.1f, 1.0f)
    val jumpdelayValue = IntegerValue("Legitjumpdelay", 3, 0, 20)
    private val onGroundValue = BoolValue("OnlyOnGround",false)
    private val nokbplusValue = BoolValue("Nokbplus",true)
    private val autoSpeed = BoolValue("AutoSpeed ",false)
    private val thirdPersonViewValue = BoolValue("ThirdPersonView", false)
    private val renderModeValue = ListValue("RenderMode", arrayOf("Circle", "Polygon", "None"), "Polygon")
    private val strafeModeValue = ListValue("strafeMode", arrayOf("Keybind", "Legit"), "Legit")
    private val lineWidthValue = FloatValue("LineWidth", 1f, 1f, 10f)
    private val fixfovValue = FloatValue("FixFOV", 90f, 0f, 180f)
    private val silent = BoolValue("silent", true)
    private val silentback = BoolValue("silentback", true)
    private val onlysprint = BoolValue("onlysprint", true)
    private lateinit var killAura: KillAura
    private lateinit var speed: Speed
    private lateinit var superKnockback: SuperKnockback
    private lateinit var wtap: Wtap
    var a = 0
    private val binds = arrayOf(
        mc.gameSettings.keyBindForward,
        mc.gameSettings.keyBindLeft,
        mc.gameSettings.keyBindBack,
        mc.gameSettings.keyBindRight
    )
    override fun onEnable() {
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
        speed = LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed
        wtap = LiquidBounce.moduleManager.getModule(Wtap::class.java) as Wtap
        superKnockback = LiquidBounce.moduleManager.getModule(SuperKnockback::class.java) as SuperKnockback
        if (!silent.get()) killAura.silentRotationValue.set(false)
        if (autoSpeed.get()) speed.state = true
        if (wtap.state && nokbplusValue.get()) superKnockback.modeValue.set("hytpacket")
        a = 0
    }
    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        val target = killAura.target
        if (renderModeValue.get() != "None") {
            if (target == null) return
            val counter = intArrayOf(0)
            if (renderModeValue.get().equals("Circle", ignoreCase = true)) {
                GL11.glPushMatrix()
                GL11.glDisable(3553)
                GL11.glEnable(2848)
                GL11.glEnable(2881)
                GL11.glEnable(2832)
                GL11.glEnable(3042)
                GL11.glBlendFunc(770, 771)
                GL11.glHint(3154, 4354)
                GL11.glHint(3155, 4354)
                GL11.glHint(3153, 4354)
                GL11.glDisable(2929)
                GL11.glDepthMask(false)
                GL11.glLineWidth(lineWidthValue.get())
                GL11.glBegin(3)
                val x = target.lastTickPosX + (target.posX - target.lastTickPosX) * event.partialTicks - mc.renderManager.viewerPosX
                val y = target.lastTickPosY + (target.posY - target.lastTickPosY) * event.partialTicks - mc.renderManager.viewerPosY
                val z = target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * event.partialTicks - mc.renderManager.viewerPosZ
                for (i in 0..359) {
                    val rainbow = Color(
                        Color.HSBtoRGB(
                            ((mc.thePlayer!!.ticksExisted / 70.0 + sin(i / 50.0 * 1.75)) % 1.0f).toFloat(),
                            0.7f,
                            1.0f
                        )
                    )
                    GL11.glColor3f(rainbow.red / 255.0f, rainbow.green / 255.0f, rainbow.blue / 255.0f)
                    GL11.glVertex3d(
                        x + radius.get() * cos(i * 6.283185307179586 / 45.0),
                        y,
                        z + radius.get() * sin(i * 6.283185307179586 / 45.0)
                    )
                }
                GL11.glEnd()
                GL11.glDepthMask(true)
                GL11.glEnable(2929)
                GL11.glDisable(2848)
                GL11.glDisable(2881)
                GL11.glEnable(2832)
                GL11.glEnable(3553)
                GL11.glPopMatrix()
            } else {
                val rad = radius.get()
                GL11.glPushMatrix()
                GL11.glDisable(3553)
                RenderUtils.startDrawing()
                GL11.glDisable(2929)
                GL11.glDepthMask(false)
                GL11.glLineWidth(lineWidthValue.get())
                GL11.glBegin(3)
                val x = target.lastTickPosX + (target.posX - target.lastTickPosX) * event.partialTicks - mc.renderManager.viewerPosX
                val y = target.lastTickPosY + (target.posY - target.lastTickPosY) * event.partialTicks - mc.renderManager.viewerPosY
                val z = target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * event.partialTicks - mc.renderManager.viewerPosZ
                for (i in 0..10) {
                    counter[0] = counter[0] + 1
                    val rainbow = Color(ColorManager.astolfoRainbow(counter[0] * 100, 5, 107))
                    //final Color rainbow = new Color(Color.HSBtoRGB((float) ((mc.thePlayer.ticksExisted / 70.0 + sin(i / 50.0 * 1.75)) % 1.0f), 0.7f, 1.0f));
                    GL11.glColor3f(rainbow.red / 255.0f, rainbow.green / 255.0f, rainbow.blue / 255.0f)
                    if (rad < 0.8 && rad > 0.0) GL11.glVertex3d(
                        x + rad * cos(i * 6.283185307179586 / 3.0),
                        y,
                        z + rad * sin(i * 6.283185307179586 / 3.0)
                    )
                    if (rad < 1.5 && rad > 0.7) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 4.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 4.0)
                        )
                    }
                    if (rad < 2.0 && rad > 1.4) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 5.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 5.0)
                        )
                    }
                    if (rad < 2.4 && rad > 1.9) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 6.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 6.0)
                        )
                    }
                    if (rad < 2.7 && rad > 2.3) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 7.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 7.0)
                        )
                    }
                    if (rad < 6.0 && rad > 2.6) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 8.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 8.0)
                        )
                    }
                    if (rad < 7.0 && rad > 5.9) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 9.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 9.0)
                        )
                    }
                    if (rad < 11.0) if (rad > 6.9) {
                        counter[0] = counter[0] + 1
                        RenderUtils.glColor(Color(80,255,255,200))
                        GL11.glVertex3d(
                            x + rad * cos(i * 6.283185307179586 / 10.0),
                            y,
                            z + rad * sin(i * 6.283185307179586 / 10.0)
                        )
                    }
                }
                GL11.glEnd()
                GL11.glDepthMask(true)
                GL11.glEnable(2929)
                RenderUtils.stopDrawing()
                GL11.glEnable(3553)
                GL11.glPopMatrix()
            }
        }
    }
    @EventTarget
    fun onMove(event: MoveEvent) {
        if((!onGroundValue.get() || mc.thePlayer!!.onGround)) {
            if (!thirdPersonViewValue.get())
                return
            if (killAura.target != null) {
                mc2.gameSettings.thirdPersonView = 3
            }else if(!killAura.state){
                mc2.gameSettings.thirdPersonView = 0
            }
        }else {
            if (!thirdPersonViewValue.get()) return
            if (killAura.target != null) {
                mc2.gameSettings.thirdPersonView = 3
            }else if(!killAura.state){
                mc2.gameSettings.thirdPersonView = 0
            }
        }
    }
    @EventTarget
    fun onStrafe(event:StrafeEvent) {
        if (strafeModeValue.get().equals("Legit", ignoreCase = true)) {
            if (RotationUtils.targetRotation != null){
                mc.gameSettings.keyBindLeft.pressed = true
                mc.gameSettings.keyBindForward.pressed = true
                val (yaw) = RotationUtils.targetRotation ?: return
                var strafe = event.strafe
                var forward = event.forward
                val friction = event.friction

                var f = strafe * strafe + forward * forward

                if (f >= 1.0E-4F) {
                    f = sqrt(f)

                    if (f < 1.0F)
                        f = 1.0F

                    f = friction / f
                    strafe *= f
                    forward *= f

                    val yawSin = sin((yaw * Math.PI / 180F).toFloat())
                    val yawCos = cos((yaw * Math.PI / 180F).toFloat())

                    val player = mc.thePlayer!!

                    player.motionX += strafe * yawCos - forward * yawSin
                    player.motionZ += forward * yawCos + strafe * yawSin
                }
                event.cancelEvent()
            }else{
                mc.gameSettings.keyBindLeft.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindLeft)
                mc.gameSettings.keyBindForward.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindForward)
            }
        }
    }


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (strafeModeValue.get().equals("Keybind", ignoreCase = true)) {
            if (killAura.target == null && a != 0) {
                mc.gameSettings.keyBindBack.pressed = false
                mc.gameSettings.keyBindLeft.pressed = false
                a = 0
            }
            if (killAura.target == null) return
            a = 1
            if (killAura.target!!.isDead || killAura.target!!.health <= 0) {
                mc.gameSettings.keyBindBack.pressed = false
                mc.gameSettings.keyBindLeft.pressed = false
                mc.gameSettings.keyBindForward.pressed = true
            }
            val target = killAura.target!!
            if (mc.thePlayer!!.getDistanceToEntityBox(target) <= radius.get()) {
                if ((mc.gameSettings.keyBindForward.isKeyDown && mc.thePlayer!!.sprinting && onlysprint.get())
                    || (mc.gameSettings.keyBindForward.isKeyDown && !onlysprint.get())
                ) {
                    mc.gameSettings.keyBindForward.pressed = false
                }
            } else {
                for (bind in binds) {
                    bind.pressed = mc.gameSettings.isKeyDown(bind)
                }
            }
            if (silent.get() && silentback.get() && RotationUtils.getRotationDifference(target) > fixfovValue.get()) {
                mc.gameSettings.keyBindBack.pressed = true
                mc.gameSettings.keyBindForward.pressed = false
            } else if (silent.get() && silentback.get()) {
                mc.gameSettings.keyBindBack.pressed = false
            }
            if (mc.thePlayer!!.getDistanceToEntityBox(target) <= (radius.get() + extrarange.get())) {
                mc.gameSettings.keyBindLeft.pressed = true
            }
        }
    }

    override fun onDisable() {
        mc2.gameSettings.thirdPersonView = 0
        mc.gameSettings.keyBindLeft.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindLeft)
        mc.gameSettings.keyBindBack.pressed = mc.gameSettings.isKeyDown(mc.gameSettings.keyBindBack)
        killAura.silentRotationValue.set(true)
        if (autoSpeed.get()) speed.state = false
        if (wtap.state && nokbplusValue.get()) superKnockback.modeValue.set("catbounce")
    }
}
