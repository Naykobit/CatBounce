package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.ScaffoldLB
import net.ccbluex.liquidbounce.utils.MovementUtils

@ModuleInfo(name = "SelfRescue", category = ModuleCategory.MISC, description = "CatBounce", cn = "自救")
class SelfRescue : Module() {


    var a = 0
    @EventTarget
    open fun isInVoid(): Boolean {
        for (i in 0..128) {
            if (MovementUtils.isOnGround(i.toDouble())) {
                return false
            }
        }
        return true
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent){
        a += 1
        val scaffoldLB = LiquidBounce.moduleManager[ScaffoldLB::class.java] as ScaffoldLB
        if ((mc.thePlayer!!.hurtTime > 0)
            && !mc.thePlayer!!.isCollidedHorizontally && !mc.thePlayer!!.isOnLadder
            && isInVoid() && !scaffoldLB.state){
            scaffoldLB.state = true
            a = 0
        }else if (scaffoldLB.state && a >= 30){
            scaffoldLB.state = false
        }
    }

    override val tag: String
        get() = "CatBounce"
}