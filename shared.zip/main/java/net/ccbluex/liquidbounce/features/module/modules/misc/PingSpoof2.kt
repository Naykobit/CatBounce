/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.exploit

import net.ccbluex.liquidbounce.api.minecraft.network.IPacket
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.timer.TimeUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.Packet
import net.minecraft.network.play.client.CPacketClientStatus
import net.minecraft.network.play.client.CPacketConfirmTransaction
import net.minecraft.network.play.client.CPacketKeepAlive
import net.minecraft.network.play.server.SPacketEntityVelocity

@ModuleInfo(name = "PingSpoof2", description = "Full", category = ModuleCategory.EXPLOIT, cn = "虚幻引擎")
class PingSpoof2 : Module() {
    private val C0f = BoolValue("C0f", true)
    private val S12 = BoolValue("S12", true)
    private val maxDelayValue: IntegerValue = object : IntegerValue("MaxDelay", 1000, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val minDelayValue = minDelayValue.get()
            if (minDelayValue > newValue) set(minDelayValue)
        }
    }

    private val minDelayValue: IntegerValue = object : IntegerValue("MinDelay", 500, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val maxDelayValue = maxDelayValue.get()
            if (maxDelayValue < newValue) set(maxDelayValue)
        }
    }

    private val packetsMap = HashMap<Packet<*>, Long?>()

    override fun onDisable() {
        packetsMap.clear()
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if ((packet is CPacketKeepAlive || packet is CPacketClientStatus
                    || (packet is SPacketEntityVelocity && S12.get()) || (packet is CPacketConfirmTransaction && C0f.get()) ) && !(mc.thePlayer!!.isDead || mc.thePlayer!!.health <= 0) && !packetsMap.containsKey(
                packet
            )
        ) {
            event.cancelEvent()
            synchronized(packetsMap) {
                packetsMap.put(
                    packet,
                    System.currentTimeMillis() + TimeUtils.randomDelay(minDelayValue.get(), maxDelayValue.get())
                )
            }
        }
    }

    @EventTarget(ignoreCondition = true)
    fun onUpdate(event: UpdateEvent?) {
        try {
            synchronized(packetsMap) {
                val iterator: MutableIterator<Map.Entry<Packet<*>, Long?>> =
                    packetsMap.entries.iterator()
                while (iterator.hasNext()) {
                    val (key, value) = iterator.next()
                    if (value!! < System.currentTimeMillis()) {
                        mc.netHandler.addToSendQueue((key as IPacket))
                        iterator.remove()
                    }
                }
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

}