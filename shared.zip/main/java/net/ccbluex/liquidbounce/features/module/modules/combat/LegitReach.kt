/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import me.utils.PacketUtils
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.BlinkUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.EntityLivingBase
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayClient
import net.minecraft.network.play.server.SPacketEntity
import java.util.concurrent.LinkedBlockingQueue

@ModuleInfo(name = "LegitReach", category = ModuleCategory.COMBAT, description="catbounce",cn = "合法长臂")
class LegitReach : Module() {
    private val mode = ListValue("Mode", arrayOf("TargetPackets"), "TargetPackets")
    private val aura = BoolValue("Aura", false)
    var currentTarget: EntityLivingBase? = null
    private val pulseTimer = MSTimer()
    private val pulseDelayValue = IntegerValue("PulseDelay", 200, 50, 500)

    private val packets = LinkedBlockingQueue<Packet<INetHandlerPlayClient>>()

    override fun onDisable() {
        clearPackets()
    }



    private fun clearPackets() {
        while (!packets.isEmpty()) {
            PacketUtils.handleSendPacket(packets.take() as Packet<INetHandlerPlayClient?>)
        }
        BlinkUtils.releasePacket()
    }

    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (aura.get() && !LiquidBounce.moduleManager[KillAura::class.java]!!.state) return
        if (event.targetEntity != currentTarget) {
            clearPackets()
            currentTarget = event.targetEntity as EntityLivingBase?
        }
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (aura.get() && !LiquidBounce.moduleManager[KillAura::class.java]!!.state) return
            if (pulseTimer.hasTimePassed(pulseDelayValue.get().toLong())) {
                pulseTimer.reset()
                clearPackets()
            }
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (aura.get() && !LiquidBounce.moduleManager[KillAura::class.java]!!.state) return

        if (mode.equals("TargetPackets")) {
            if (packet is SPacketEntity && LiquidBounce.combatManager.inCombat) {
                if (packet.getEntity(mc2.world) == currentTarget) {
                    event.cancelEvent()
                    packets.add(packet as Packet<INetHandlerPlayClient>)
                }
            }
        }
    }
}

