/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue

@ModuleInfo(name = "AutoFLY", category = ModuleCategory.MOVEMENT, description = "Stevie", cn = "托马斯超级螺旋无敌爆炸原地升天术")
class AutoFLY : Module() {

    private val disValue = IntegerValue("AutodisDelay", 39, 0, 100)
    private val autodis = BoolValue("Autodis", true)
    var a = 0;
    var tick = 0

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        a += 1
        tick += 1
        if(a == 4){
            LiquidBounce.moduleManager[TNTFLY::class.java].state = true
        }
        if(tick == disValue.get() && autodis.get()){
            LiquidBounce.moduleManager[TNTFLY::class.java].state = false
        }
        mc.gameSettings.keyBindJump.pressed = false
    }
    override fun onDisable() {
        LiquidBounce.moduleManager[TNTFLY::class.java].state = false
    }
    override fun onEnable() {
        a = 0
        tick = -4
        mc.thePlayer!!.jump()
    }
}
