package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.AutoWalk
import net.ccbluex.liquidbounce.features.module.modules.movement.Step
import net.ccbluex.liquidbounce.features.module.modules.player.AntiAFK
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(name = "BattleRobot", category = ModuleCategory.COMBAT, description = "CatBounce", cn = "战斗机器人")
class BattleRobot : Module() {
    private var hm = 0
    private var s = 0
    private var w = 0

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura
        val aimbot = LiquidBounce.moduleManager[Aimbot::class.java] as Aimbot
        val antiafk = LiquidBounce.moduleManager[AntiAFK::class.java] as AntiAFK
        hm += 1
        if (hm == 20) {
            s += 1
            hm = 0
        }
        if (mc.thePlayer!!.isDead || mc.thePlayer!!.health < 0) {
            s = 0
            hm = 0
            aimbot.state = false
            aura.state = false
        }
        if (s == 5) {
            aimbot.state = true
            s = 0
            hm = 0
            aura.state = true
        }
        if (s == 1) {
            mc.thePlayer!!.rotationYaw = 135f
            mc.thePlayer!!.rotationPitch = 0f
        }
        antiafk.state = s >=5 && aura.target == null
        if (aura.target == null){
            w += 1
        }else if (aura.state){
            w = 0
        }
        if (w >= 100) {
            mc.gameSettings.keyBindBack.pressed = true
        }
        if (w == 100) mc.thePlayer!!.rotationYaw += 45f
        if (w >= 135) {
            mc.gameSettings.keyBindBack.pressed = false
            w = 0
        }
    }


    override fun onEnable() {
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b已开启战斗Ai")
        val step = LiquidBounce.moduleManager[Step::class.java] as Step
        val autoWalk = LiquidBounce.moduleManager[AutoWalk::class.java] as AutoWalk
        hm = 0
        s = 0
        step.state = true
        autoWalk.state = true
    }

    override fun onDisable() {
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b已关闭战斗Ai")
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura
        val aimbot = LiquidBounce.moduleManager[Aimbot::class.java] as Aimbot
        val antiafk = LiquidBounce.moduleManager[AntiAFK::class.java] as AntiAFK
        val step = LiquidBounce.moduleManager[Step::class.java] as Step
        val autoWalk = LiquidBounce.moduleManager[AutoWalk::class.java] as AutoWalk
        antiafk.state = false
        aura.state = false
        step.state = false
        autoWalk.state = false
        aimbot.state = false
    }
}