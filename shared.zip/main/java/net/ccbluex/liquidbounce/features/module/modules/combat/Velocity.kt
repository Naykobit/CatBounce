/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayClient
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketEntityVelocity
import java.util.*
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.cos
import kotlin.math.sin

@ModuleInfo(name = "Velocity", description = "Allows you to modify the amount of knockback you take.", category = ModuleCategory.COMBAT, cn = "C03反击退")
class Velocity : Module() {

    /**
     * OPTIONS
     */
    private val horizontalValue = FloatValue("Horizontal", 0F, 0F, 1F)
    private val verticalValue = FloatValue("Vertical", 0F, 0F, 1F)
    val modeValue = ListValue("Mode", arrayOf("OldAAC4", "Simple" ,"AAC4Reduce" ,"AAC5Reduce" ,"Grim" ,"AAC4" ,"Tick" ,"CanCelS12" ,"AAC", "AACPush", "AACZero",
            "Reverse", "SmoothReverse" ,"Jump", "HytJump" ,"Glitch"), "Simple")

    // Reverse
    private val reverseStrengthValue = FloatValue("ReverseStrength", 1F, 0.1F, 1F)
    private val reverse2StrengthValue = FloatValue("SmoothReverseStrength", 0.05F, 0.02F, 0.1F)

    // Push Reducer
    private val aacPushXZReducerValue = FloatValue("AACPushXZReducer", 2F, 1F, 3F)
    private val aacPushYReducerValue = BoolValue("AACPushYReducer", true)

    //Tick
    private val velocityTickValue = IntegerValue("VelocityTick", 1, 0, 10)

    //TNT
    private val nottntvelocity = BoolValue("NoTNTVelocity",false)

    //Debug Test
    private val debug = BoolValue("VelocityDebug",false)

    //Only
    private val onlyground = BoolValue("OnlyGround",false)
    private val onlyaura = BoolValue("OnlyKillAura",false)

    //Grim
    private val packets = LinkedBlockingQueue<Packet<*>>()
    private var disableLogger = false
    private val inBus = LinkedList<Packet<INetHandlerPlayClient>>()
    var cancelPackets = 0
    private var resetPersec = 8
    private var updates = 0

    /**
     * VALUES
     */
    private var velocityTimer = MSTimer()
    private var velocityInput = false
    private var velocityTick = 0
    private var usedTimer = false

    // SmoothReverse
    private var reverseHurt = false

    // AACPush
    private var jump = false

    override val tag: String
        get() = modeValue.get()

    override fun onDisable() {
        mc.thePlayer?.speedInAir = 0.02F
        if(modeValue.get() == "Grim"){
            inBus.clear()
            cancelPackets = 0
            blink()
        }
    }

    override fun onEnable() {
        cancelPackets = 0
        inBus.clear()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if(velocityInput) {
            velocityTick++
        }else velocityTick = 0

        val thePlayer = mc.thePlayer ?: return

        if(onlyaura.get()){
            val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java)
            if(!killAura.state) return
        }

        if(onlyground.get()){
            if(!thePlayer.onGround) return
        }

        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return

        if(usedTimer){
            mc.timer.timerSpeed = 1F
            usedTimer = false
        }

        updates++
        if (resetPersec > 0) {
            if (updates >= 0) {
                updates = 0
                if (cancelPackets > 0){
                    cancelPackets--
                }
            }
        }
        if(cancelPackets == 0){
            blink()
        }

        when (modeValue.get().toLowerCase()) {
            "jump" -> if (thePlayer.hurtTime > 0 && thePlayer.onGround) {
                thePlayer.motionY = 0.42

                val yaw = thePlayer.rotationYaw * 0.017453292F

                thePlayer.motionX -= sin(yaw) * 0.2
                thePlayer.motionZ += cos(yaw) * 0.2
            }
            "hytjump" -> if (thePlayer.onGround) {
                if (thePlayer.hurtTime > 0 && thePlayer.motionX != 0.0 && thePlayer.motionY != 0.0){
                    thePlayer.onGround = true
                }
                if (thePlayer.hurtResistantTime > 0 ){
                    thePlayer.motionY = thePlayer.motionY - 0.014999993
                }
                if (thePlayer.hurtResistantTime > 19 ){
                    thePlayer.motionX = thePlayer.motionX / 1.5f
                    thePlayer.motionZ = thePlayer.motionZ / 1.5f

                }
            }
            "tick" -> {
                if(velocityTick > velocityTickValue.get()) {
                    if(thePlayer.motionY > 0) thePlayer.motionY = 0.0
                    thePlayer.motionX = 0.0
                    thePlayer.motionZ = 0.0
                    thePlayer.jumpMovementFactor = -0.00001f
                    velocityInput = false
                }
                if(thePlayer.onGround && velocityTick > 1) {
                    velocityInput = false
                }
            }

            "glitch" -> {
                thePlayer.noClip = velocityInput

                if (thePlayer.hurtTime == 7)
                    thePlayer.motionY = 0.4

                velocityInput = false
            }

            "reverse" -> {
                if (!velocityInput)
                    return

                if (!thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.speed * reverseStrengthValue.get())
                } else if (velocityTimer.hasTimePassed(80L))
                    velocityInput = false
            }

            "aac4reduce" -> {
                if (thePlayer.hurtTime > 0 && !thePlayer.onGround && velocityInput && velocityTimer.hasTimePassed(80L)) {
                    thePlayer.motionX *= 0.62
                    thePlayer.motionZ *= 0.62
                }
                if (velocityInput && (thePlayer.hurtTime <4 || thePlayer.onGround) && velocityTimer.hasTimePassed(120L)) {
                    velocityInput = false
                }
            }

            "aac5reduce" -> {
                if (thePlayer.hurtTime > 1 && velocityInput) {
                    thePlayer.motionX *= 0.81
                    thePlayer.motionZ *= 0.81
                }
                if (velocityInput && (thePlayer.hurtTime <5 || thePlayer.onGround) && velocityTimer.hasTimePassed(120L)) {
                    velocityInput = false
                }
            }

            "oldaac4" -> {
                if (!thePlayer.onGround) {
                    if (velocityInput) {
                        thePlayer.speedInAir = 0.02f
                        thePlayer.motionX *= 0.6
                        thePlayer.motionZ *= 0.6
                    }
                } else if (velocityTimer.hasTimePassed(80L)) {
                    velocityInput = false
                    thePlayer.speedInAir = 0.02f
                }
            }

            "smoothreverse" -> {
                if (!velocityInput) {
                    thePlayer.speedInAir = 0.02F
                    return
                }

                if (thePlayer.hurtTime > 0)
                    reverseHurt = true

                if (!thePlayer.onGround) {
                    if (reverseHurt)
                        thePlayer.speedInAir = reverse2StrengthValue.get()
                } else if (velocityTimer.hasTimePassed(80L)) {
                    velocityInput = false
                    reverseHurt = false
                }
            }

            "aac" -> if (velocityInput && velocityTimer.hasTimePassed(80L)) {
                thePlayer.motionX *= horizontalValue.get()
                thePlayer.motionZ *= horizontalValue.get()
                //mc.thePlayer.motionY *= verticalValue.get() ?
                velocityInput = false
            }

            "aacpush" -> {
                if (jump) {
                    if (thePlayer.onGround)
                        jump = false
                } else {
                    // Strafe
                    if (thePlayer.hurtTime > 0 && thePlayer.motionX != 0.0 && thePlayer.motionZ != 0.0)
                        thePlayer.onGround = true

                    // Reduce Y
                    if (thePlayer.hurtResistantTime > 0 && aacPushYReducerValue.get()
                            && !LiquidBounce.moduleManager[Speed::class.java].state)
                        thePlayer.motionY -= 0.014999993
                }

                // Reduce XZ
                if (thePlayer.hurtResistantTime >= 19) {
                    val reduce = aacPushXZReducerValue.get()

                    thePlayer.motionX /= reduce
                    thePlayer.motionZ /= reduce
                }
            }

            "aaczero" -> if (thePlayer.hurtTime > 0) {
                if (!velocityInput || thePlayer.onGround || thePlayer.fallDistance > 2F)
                    return

                thePlayer.motionY -= 1.0
                thePlayer.isAirBorne = true
                thePlayer.onGround = true
            } else
                velocityInput = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val thePlayer = mc.thePlayer ?: return

        val packet = event.packet

        if (nottntvelocity.get()) {
            if (classProvider.isSPacketExplosion(packet)) {
                event.cancelEvent()
            }
        }

        if (classProvider.isSPacketEntityVelocity(packet)) {
            val packetEntityVelocity = packet.asSPacketEntityVelocity()

            velocityTimer.reset()
            velocityTick = 0

            if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                return

            if (debug.get()) {
                ClientUtils.displayChatMessage("§b[§bCatBounce]§dVelocity MotionY §f>> " + thePlayer.motionY)
            }

            velocityTimer.reset()

            when (modeValue.get().toLowerCase()) {
                "simple" -> {
                    val horizontal = horizontalValue.get()
                    val vertical = verticalValue.get()
                    if (horizontal == 0F && vertical == 0F)
                        event.cancelEvent()

                    packetEntityVelocity.motionX = (packetEntityVelocity.motionX * horizontal).toInt()
                    packetEntityVelocity.motionY = (packetEntityVelocity.motionY * vertical).toInt()
                    packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * horizontal).toInt()
                }

                "tick" -> {
                    velocityInput = true
                    val horizontal = horizontalValue.get()
                    val vertical = verticalValue.get()
                    if (horizontal == 0F && vertical == 0F) {
                        event.cancelEvent()
                    }

                    packetEntityVelocity.motionX = (packetEntityVelocity.motionX * horizontal).toInt()
                    packetEntityVelocity.motionY = (packetEntityVelocity.motionY * vertical).toInt()
                    packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * horizontal).toInt()
                }

                "aac4reduce" -> {
                    velocityInput = true
                    packetEntityVelocity.motionX = (packetEntityVelocity.motionX * 0.6).toInt()
                    packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * 0.6).toInt()
                }

                "matrixsimple" -> {
                    packetEntityVelocity.motionX = (packetEntityVelocity.motionX * 0.36).toInt()
                    packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * 0.36).toInt()
                    if (thePlayer.onGround) {
                        packetEntityVelocity.motionX = (packetEntityVelocity.motionX * 0.9).toInt()
                        packetEntityVelocity.motionZ = (packetEntityVelocity.motionZ * 0.9).toInt()
                    }
                }

                "grim" ->{
                    event.cancelEvent()
                    cancelPackets = 3
                }

                "cancels12" -> event.cancelEvent()

                "aac", "oldaac4", "reverse", "aac5reduce", "smoothreverse", "aaczero" -> velocityInput = true

                "glitch" -> {
                    if (!thePlayer.onGround)
                        return

                    velocityInput = true
                    event.cancelEvent()
                }
            }
            if(modeValue.get() == "Grim"){
                if(cancelPackets > 0) {
                    if (mc.thePlayer == null || disableLogger) return
                    if (packet.unwrap() is CPacketPlayer) // Cancel all movement stuff
                        event.cancelEvent()
                    if (packet.unwrap() is CPacketPlayer.Position || packet is CPacketPlayer.PositionRotation ||
                            packet.unwrap() is CPacketPlayerTryUseItemOnBlock ||
                            packet.unwrap() is CPacketAnimation ||
                            packet.unwrap() is CPacketEntityAction || packet is CPacketUseEntity) {
                        event.cancelEvent()
                        packets.add(packet.unwrap())
                    }
                    if (packet.unwrap()::class.java.simpleName.startsWith("S", true)) {
                        if (packet.unwrap() is SPacketEntityVelocity && (mc.theWorld?.getEntityByID((packet.unwrap() as SPacketEntityVelocity).entityID) ?: return) == mc.thePlayer) {
                            return
                        }
                        event.cancelEvent()
                        inBus.add(packet.unwrap() as Packet<INetHandlerPlayClient>)
                    }
                }
            }
        }
    }

    private fun blink() {
        try {
            disableLogger = true
            while (!packets.isEmpty()) {
                mc2.connection!!.networkManager.sendPacket(packets.take())
            }
            while (!inBus.isEmpty()) {
                inBus.poll()?.processPacket(mc2.connection!!)
            }
            disableLogger = false
        } catch (e: Exception) {
            e.printStackTrace()
            disableLogger = false
        }
    }

    @EventTarget
    fun onJump(event: JumpEvent) {
        val thePlayer = mc.thePlayer

        if (thePlayer == null || thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return

        when (modeValue.get().toLowerCase()) {
            "aacpush" -> {
                jump = true

                if (!thePlayer.isCollidedVertically)
                    event.cancelEvent()
            }
            "oldaac4" -> {
                if (thePlayer.hurtTime > 0) {
                    event.cancelEvent()
                    velocityInput = false
                }
            }
            "aaczero" -> if (thePlayer.hurtTime > 0)
                event.cancelEvent()
        }
    }
}