package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.*
import net.ccbluex.liquidbounce.features.module.modules.movement.InventoryMove
import net.ccbluex.liquidbounce.features.module.modules.movement.TNTFLY
import net.ccbluex.liquidbounce.features.module.modules.player.Eagle
import net.ccbluex.liquidbounce.features.module.modules.player.InventoryCleaner
import net.ccbluex.liquidbounce.features.module.modules.render.ESP
import net.ccbluex.liquidbounce.features.module.modules.render.ESP2
import net.ccbluex.liquidbounce.features.module.modules.render.NameTags
import net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold2
import net.ccbluex.liquidbounce.features.module.modules.world.StealerPlus
import net.ccbluex.liquidbounce.value.BoolValue

@ModuleInfo(name = "Autodisable", description = "CatBounce", category = ModuleCategory.MISC, cn = "自动关闭")
class Autodisable : Module() {


    val nomoveValue = BoolValue("nomovebypass", true)
    private val sca = BoolValue("sca", true)
    private val wapon = BoolValue("autoweapon", true)
    private val velka = BoolValue("velka", true)


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura ?
        val scaffold = LiquidBounce.moduleManager[Scaffold::class.java] as Scaffold
        val inventoryMove = LiquidBounce.moduleManager[InventoryMove::class.java] as InventoryMove
         val noBadPacket = LiquidBounce.moduleManager[NoBadPacket::class.java] as NoBadPacket
         val autoWeapon = LiquidBounce.moduleManager[AutoWeapon::class.java] as AutoWeapon
         val velocity2 = LiquidBounce.moduleManager[Velocity2::class.java] as Velocity2
         val eagle = LiquidBounce.moduleManager[Eagle::class.java] as Eagle
         val esp = LiquidBounce.moduleManager[ESP::class.java] as ESP
         val esp2 = LiquidBounce.moduleManager[ESP2::class.java] as ESP2
         val nameTags = LiquidBounce.moduleManager[NameTags::class.java] as NameTags
         val stealerPlus = LiquidBounce.moduleManager[StealerPlus::class.java] as StealerPlus
         val inventoryCleaner = LiquidBounce.moduleManager[InventoryCleaner::class.java] as InventoryCleaner
         val chestStealer = LiquidBounce.moduleManager[ChestStealer::class.java] as ChestStealer
         val grimVel = LiquidBounce.moduleManager[GrimVelocity4::class.java] as GrimVelocity4
         val scaffold2 = LiquidBounce.moduleManager[Scaffold2::class.java] as Scaffold2
         val tntfly = LiquidBounce.moduleManager[TNTFLY::class.java] as TNTFLY
         val antiFireBall = LiquidBounce.moduleManager[AntiFireBall::class.java] as AntiFireBall
         val autoArmor = LiquidBounce.moduleManager[AutoArmor::class.java] as AutoArmor

        if(!mc.thePlayer!!.onGround && nomoveValue.get()) {
            inventoryMove.noMoveClicksValue.set(true)
        } else {
            inventoryMove.noMoveClicksValue.set(false)
        }
        if (aura != null) {
            if(aura.state && wapon.get()){
                autoWeapon.state = true
            }else if(wapon.get()){
                autoWeapon.state = false
            }
        }
        if (aura != null) {
            if(aura.state && velka.get()){
                grimVel.state = true
            }else if(velka.get()){
                grimVel.state = false
            }
        }
        if(scaffold.state){
            if (aura != null) {
                aura.state = false
            }
        }
        if(grimVel.state){
            velocity2.state = false
        }else{
            velocity2.state = true
        }
        if(scaffold.state && sca.get()){
            eagle.state = true
            scaffold2.state = true
        }else if(sca.get()){
            eagle.state = false
            scaffold2.state = false
        }
        if(tntfly.state){
            antiFireBall.state = false
        }else{
            antiFireBall.state = true
        }
        if(esp.state){
            esp2.state = false
            nameTags.state = false
        }else{
            esp2.state = true
            nameTags.state = true
        }
        if (mc.thePlayer!!.isDead || mc.thePlayer!!.health <= 0) {
            if (aura != null) {
                aura.state = false
            }
        }
    }
}