package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.BlockType
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.ScaHelperNew
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.network.play.client.CPacketPlayerDigging
import net.minecraft.network.play.server.SPacketPlayerPosLook

@ModuleInfo(name = "Safeauramode", description = "CatBounce",category = ModuleCategory.COMBAT, cn = "安全模块")
class Safeauramode : Module() {
    private var a = 0
    private var b = 0
    private var diggingtime = 0
    private val strict = BoolValue("strict", false)
    private val safeonice = BoolValue("safeonice", true)
    private val safeclimb = BoolValue("safeclimb", true)
    private val safedigging = BoolValue("safedigging", true)
    private val safeSwimmer = BoolValue("safeSwimmer", true)
    private val safeStairs = BoolValue("safeStairs", true)
    private val safePlace = BoolValue("safePlace", true)
    private val safeantifireball = BoolValue("safeantifireball", true)
    val saferangeValue = FloatValue("saferangeValue", 3.19f, 3f, 6f)
    var normalgroundrangeValue = FloatValue("normalgroundrangeValue", 3f, 3f, 6f)
    var normalairrangeValue = FloatValue("normalairrangeValue", 3f, 3f, 6f)
    private var walkingDown = false
    private var onice = false
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura?
        val packet = event.packet.unwrap()
        if (packet is SPacketPlayerPosLook){
            a = 5
        }
        if (((packet is CPacketPlayerDigging) || diggingtime > 3) && safedigging.get() && mc.theWorld!!.getBlockState(mc.objectMouseOver!!.blockPos!!).block != classProvider.getBlockEnum(BlockType.AIR)) {
            aura!!.switchDelayValue.set(2000)
            aura!!.groundRangeValue.set(saferangeValue.get())
            aura!!.airRangeValue.set(saferangeValue.get())
            b = 0
        } else if (b >= 20 && safedigging.get()){
            aura!!.switchDelayValue.set(0)
            aura!!.groundRangeValue.set(normalgroundrangeValue.get())
            aura!!.airRangeValue.set(normalairrangeValue.get())
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (a >= 0) a -= 1
        b += 1
        val thePlayer = mc.thePlayer ?: return
        if (mc.gameSettings.keyBindAttack.isKeyDown && mc.theWorld!!.getBlockState(mc.objectMouseOver!!.blockPos!!).block != classProvider.getBlockEnum(BlockType.AIR)) {
            diggingtime += 1
        }else{
            diggingtime = 0
        }
        if (thePlayer.onGround && !thePlayer.isOnLadder && !thePlayer.sneaking && thePlayer.sprinting && thePlayer.movementInput.moveForward > 0.0) {
            BlockUtils.getMaterial(thePlayer.position.down()).let {
                onice = it == classProvider.getBlockEnum(BlockType.ICE) || it == classProvider.getBlockEnum(BlockType.ICE_PACKED)
            }
        }
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura?

        val ScaHelperNew = LiquidBounce.moduleManager[ScaHelperNew::class.java] as ScaHelperNew?
        val antiFireBall = LiquidBounce.moduleManager[AntiFireBall::class.java] as AntiFireBall?
        if (safeantifireball.get() && aura!!.target != null ){
            antiFireBall!!.state = false
        } else if(safeantifireball.get()){
            antiFireBall!!.state = true
        }
        if ( (classProvider.isItemBlock(mc.thePlayer!!.heldItem!!.item) && safePlace.get()) || a >= 3 || ScaHelperNew!!.state){
            if (aura != null) {
                aura.state = false

            }
        }
        if (thePlayer.fallDistance > 0 && !walkingDown)
            walkingDown = true
        else if (thePlayer.posY > thePlayer.prevChasingPosY)
            walkingDown = false
        if ((safeclimb.get() && thePlayer.isCollidedHorizontally && thePlayer.isOnLadder)  || (safeSwimmer.get() && thePlayer.isInWater && classProvider.isBlockLiquid(
                BlockUtils.getBlock(thePlayer.position)
            )) || (safeStairs.get() && classProvider.isBlockStairs(BlockUtils.getBlock(WBlockPos(thePlayer.posX, thePlayer.entityBoundingBox.minY, thePlayer.posZ)))
                    && !walkingDown) || (safeonice.get() && onice)){
            if (strict.get()){
                if (aura != null) {
                    aura.state = false

                }
            }
            aura!!.groundRangeValue.set(saferangeValue.get())
            aura!!.airRangeValue.set(saferangeValue.get())
        } else if(!safedigging.get()){
            aura!!.groundRangeValue.set(normalgroundrangeValue.get())
            aura!!.airRangeValue.set(normalairrangeValue.get())
        }
    }

}