package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.GrimVel
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.client.CPacketUseEntity
import net.minecraft.network.play.server.SPacketChat
import java.util.regex.Pattern

@ModuleInfo(name = "PacketMonitor", category =ModuleCategory.MISC, description = "CatBounce", cn = "发包检测")
class PacketMonitor : Module() {

    private val Debug = BoolValue("Debug", true)
    private val Maxpacket = IntegerValue("Maxpacket", 21, 1, 100)
    private val Hubpacket = IntegerValue("Hubpacket", 50, 1, 100)
    private val Overflow_count = IntegerValue("overflow_count", 5, 1, 20)
    private var Count = 0;
    private var ticks = 0;
    private var a = false;
    private var b = 0
    private var c = 0

    override fun onEnable() {
        ticks = 0;
        a = false;
        Count = 0;
        b = 0
        c = 0
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val  e = event.packet.unwrap()
        val packet = event.packet.unwrap()
        if ((packet is SPacketChat) && !packet.chatComponent.unformattedText.contains(":")) {
            val chat = packet.chatComponent.unformattedText
            val matcher = Pattern.compile("游戏开始").matcher(chat)
            val matcher2 = Pattern.compile("恭喜").matcher(chat)
            val matcher3 = Pattern.compile("加入了游戏").matcher(chat)
            val matcher5 = Pattern.compile("正在进行匹配").matcher(chat)
            val matcher6 = Pattern.compile("已为你自动开启").matcher(chat)
            val matcher7 = Pattern.compile("开始倒计时").matcher(chat)
            if (matcher.find() || matcher2.find() || matcher3.find() || matcher5.find() || matcher6.find() || matcher7.find()) {
                b = 0
                if (Debug.get()) {
                    ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§dPacket清除")
                }
            }
        }
        if ((e is CPacketUseEntity) && b >= 20 ){
            Count += 1
            a = true
        }
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        b += 1
        if (a) {
            ticks++;
        }
        if (Count > Maxpacket.get()) {
            c += 1
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d发包过多:$Count/s")
            }
        }
        if (Count >= Hubpacket.get()) {
            c = 0
            mc.thePlayer!!.sendChatMessage("/hub")
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d发包超级多:$Count/s")
            }
        }
        if (c >= Overflow_count.get()) {
            c = 0
            mc.thePlayer!!.sendChatMessage("/hub")
            if (Debug.get()) {
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d发包过多次数过多")
            }
        }
        val grimfull = LiquidBounce.moduleManager[GrimVel::class.java] as GrimVel
        if (grimfull.state){
            c = 0
            b = 0
            Count = 0
        }
        if (ticks == 20) {
            a = false
            ticks = 0;
            Count = 0;
        }
    }

}