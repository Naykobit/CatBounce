/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils

@ModuleInfo(name = "Cnmodule", category = ModuleCategory.RENDER, description = "CatBounce", cn = "汉化")
class Cnmodule : Module() {
    override fun onEnable() {
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§n输入.reload完成汉化")
    }

    override fun onDisable() {
        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§n输入.reload恢复英文模式")
    }
}
