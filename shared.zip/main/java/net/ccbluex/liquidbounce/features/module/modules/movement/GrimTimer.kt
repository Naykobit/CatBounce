package net.ccbluex.liquidbounce.features.module.modules.movement


import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.*


@ModuleInfo(name = "GrimTimer", description = "你需要原地不动一会儿", category = ModuleCategory.MOVEMENT, cn = "严格的变速")
class GrimTimer : Module() {

    private val speedValue = FloatValue("Speed", 2F, 0.1F, 10F)
    private val onMoveValue = BoolValue("OnMove", true)

    override fun onDisable() {
        if (mc.thePlayer == null)
            return
        mc.timer.timerSpeed = 1F
    }
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is CPacketKeepAlive) {
            event.cancelEvent()
        }
        if (packet is CPacketEntityAction ) {
            event.cancelEvent()
        }
        if (packet is CPacketPlayerDigging ) {
            event.cancelEvent()
        }
        if (packet is CPacketPlayerAbilities) {
            event.cancelEvent()
        }
        if (packet is CPacketClientStatus ) {
            event.cancelEvent()
        }
        if (packet is SPacketAnimation ) {
            event.cancelEvent()
        }
        if (packet is SPacketDisplayObjective ) {
            event.cancelEvent()
        }
        if (packet is SPacketEntity ) {
            event.cancelEvent()
        }
        if (packet is SPacketConfirmTransaction ) {
            event.cancelEvent()
        }
        if (packet is SPacketPlayerAbilities ) {
            event.cancelEvent()
        }
        if (packet is SPacketTimeUpdate ) {
            event.cancelEvent()
        }
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if(MovementUtils.isMoving || !onMoveValue.get()) {
            mc.timer.timerSpeed = speedValue.get()
            return
        }

        mc.timer.timerSpeed = 1F
    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        if (event.worldClient != null)
            return

        state = false
    }
}