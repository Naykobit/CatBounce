/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import java.lang.Math.abs

class Prediction : SpeedMode("Prediction") {
    override fun onMotion(event: MotionEvent) {
        if (!MovementUtils.isMoving
            || mc.thePlayer!!.isInLava
            || mc.thePlayer!!.isInWater
            || mc.thePlayer!!.isOnLadder) {
            return
        }
        if (mc.thePlayer!!.onGround && !mc.gameSettings.keyBindJump.isKeyDown)
            mc.thePlayer!!.jump()

        if (abs(mc.thePlayer!!.motionY) < 0.005) {
            mc.thePlayer!!.motionY = (mc.thePlayer!!.motionY - 0.08) * 0.98F
        }
    }

    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {}
}