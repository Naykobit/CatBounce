/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly
import net.ccbluex.liquidbounce.utils.render.shader.shaders.RainbowFontShader.offset
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import kotlin.random.Random

@ModuleInfo(name = "Criticals", description = "Automatically deals critical hits.", category = ModuleCategory.COMBAT, cn = "刀暴")
class Criticals : Module() {

    val modeValue = ListValue("Mode", arrayOf("newpacket","non-calculable","invalid","nanopacket","verussmart","Grimpacket","Packet4","C03","Packet","Packet2", "Packet3","Vulcan", "AAC4ByHyt" ,"SpartanSemi", "NcpPacket", "Vanilla","AAC4","AAC5","VerusSmart","NoGround", "Hop", "TPHop", "Jump", "LowJump", "Visual"), "Packet")
    val delayValue = IntegerValue("Delay", 0, 0, 500)
    private val hurtTimeValue = IntegerValue("HurtTime", 10, 0, 10)
    val packet = ListValue("PacketMode" , arrayOf("C04","C06"),"C04")
    private val debug = BoolValue("Debug", true)
    private val ramd = BoolValue("Rnd Lv", true)

    private var velocityInput = false
    private var docritical = false
    var attacks = 0
    val msTimer = MSTimer()
    val restVL = MSTimer()
    private var counter = 0
    override fun onEnable() {
        if (modeValue.get().equals("NoGround", ignoreCase = true))
            mc.thePlayer!!.jump()
        if (modeValue.get().equals("C03", ignoreCase = true))
            mc.thePlayer!!.jump()
    }




    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (classProvider.isEntityLivingBase(event.targetEntity)) {
            val thePlayer = mc.thePlayer ?: return
            val entity = event.targetEntity!!.asEntityLivingBase()
            fun sendCriticalPacket(xOffset: Double = 0.0, yOffset: Double = 0.0, zOffset: Double = 0.0, ground: Boolean) {
                val posX = thePlayer.posX + xOffset
                val posY = thePlayer.posY + yOffset
                val posZ = thePlayer.posZ + zOffset
                if (packet.get() == "C06") {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosLook(posX, posY, posZ, thePlayer.rotationYaw, thePlayer.rotationPitch, ground))
                } else {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(posX, posY, posZ, ground))
                }
            }
            if (!thePlayer.onGround || thePlayer.isOnLadder || thePlayer.isInWeb || thePlayer.isInWater ||
                    thePlayer.isInLava || thePlayer.ridingEntity != null || entity.hurtTime > hurtTimeValue.get() ||
                    LiquidBounce.moduleManager[Fly::class.java].state || !msTimer.hasTimePassed(delayValue.get().toLong()))
                return

            val x = thePlayer.posX
            val y = thePlayer.posY
            val z = thePlayer.posZ

            when (modeValue.get().toLowerCase()) {
                "Grimpacket" -> {
                    attacks++
                    if (!thePlayer.onGround) {
                        mc.thePlayer!!.motionZ *= 0
                        mc.thePlayer!!.motionX *= 0
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 3e-14, mc.thePlayer!!.posZ, true))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 8e-15, mc.thePlayer!!.posZ, true))
                        if (debug.get())
                            thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                    }
                }
                "nanopacket" -> {
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 0.42, mc.thePlayer!!.posZ, false))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 8e-15, mc.thePlayer!!.posZ, true))
                }
                "packet" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.0625, z, true))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 1.1E-5, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y, z, false))
                    thePlayer.onCriticalHit(entity)
                }
                "newpacket" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.05250000001304, z, true))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.00150000001304, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.01400000001304, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.00150000001304, z, false))
                    thePlayer.onCriticalHit(entity)
                }
                "packet4" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.11, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.1100013579, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.0000013579, z, false))
                    thePlayer.onCriticalHit(entity)
                }
                "non-calculable" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 1E-5, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 1E-7, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y - 1E-6, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y - 1E-4, z, false))
                }

                "invalid" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 1E+27, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y - 1E+68, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 1E+41, z, false))
                }

                "verussmart" -> {
                    counter++
                    if (counter == 1) {
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.001, z, true))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y, z, false))
                    }
                    if (counter >= 5)
                        counter = 0
                }
                "AAC5" -> {
                    mc.thePlayer!!.sendQueue.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                            mc.thePlayer!!.posX, mc.thePlayer!!.posY + 0.0625, mc.thePlayer!!.posZ, false
                        )
                    )
                    mc.thePlayer!!.sendQueue.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                            mc.thePlayer!!.posX,
                            mc.thePlayer!!.posY + 0.09858,
                            mc.thePlayer!!.posZ,
                            false
                        )
                    )
                    mc.thePlayer!!.sendQueue.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                            mc.thePlayer!!.posX,
                            mc.thePlayer!!.posY + 0.04114514,
                            mc.thePlayer!!.posZ,
                            false
                        )
                    )
                    mc.thePlayer!!.sendQueue.addToSendQueue(
                        classProvider.createCPacketPlayerPosition(
                            mc.thePlayer!!.posX,
                            mc.thePlayer!!.posY + 0.025,
                            mc.thePlayer!!.posZ,
                            false
                        )
                    )
                }
                "spartansemi" -> {
                    attacks++
                    if (attacks > 6) {
                        sendCriticalPacket(yOffset = 0.01, ground = false)
                        sendCriticalPacket(yOffset = 0.0000000001, ground = false)
                        sendCriticalPacket(yOffset = 0.114514, ground = false)
                        attacks = 0
                        if (debug.get())
                            thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))

                    }
                }
                "ncppacket" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.11, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.1100013579, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.0000013579, z, false))
                    thePlayer.onCriticalHit(entity)
                    if (debug.get())
                        thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                }
                "aac4byhyt" ->{
                    attacks++
                    if (attacks > 5) {
                        sendCriticalPacket(yOffset = 0.0114514, ground = false)
                        sendCriticalPacket(yOffset = 0.0019 ,ground = false)
                        sendCriticalPacket(yOffset = 0.000001 ,ground = false)
                        attacks = 0
                        if (debug.get())
                            thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                    }
                }
                "vanilla" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.05250000001304, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.00150000001304, z, false))
                    if (debug.get())
                        thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                }
                "aac4" -> {
                    mc.thePlayer!!.motionZ *= 0
                    mc.thePlayer!!.motionX *= 0
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 3e-14, mc.thePlayer!!.posZ, true))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 8e-15, mc.thePlayer!!.posZ, true))
                    if (debug.get())
                        thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))

                }
                "vulcan" -> {
                    attacks++
                    if (attacks > 6) {
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.2, z, false))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.1216, z, false))
                        attacks = 0
                        if (debug.get())
                            thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                    }
                }
                "verussmart" -> {
                    counter++
                    if (counter == 1) {
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.001, z, true))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y, z, false))
                    }
                    if (counter >= 5)
                        counter = 0
                    if (debug.get())
                        thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                }
                "hop" -> {
                    thePlayer.motionY = 0.1
                    thePlayer.fallDistance = 0.1f
                    thePlayer.onGround = false
                }

                "tphop" -> {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.02, z, false))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.01, z, false))
                    thePlayer.setPosition(x, y + 0.01, z)
                }
                "jump" -> thePlayer.motionY = 0.42
                "lowjump" -> thePlayer.motionY = 0.3425
                "verus" -> {
                    attacks++
                    if (attacks > 4) {
                        attacks = 0
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + 0.001, z, false))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y, z, false))
                        if (debug.get())23231231
                            thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                        mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                    }
                }
                "packet2" -> {
                    val randomCritBoolean = Random.nextBoolean()
                    var resetLVBoolean = false
                    if (restVL.hasTimePassed(20000) && ramd.get() && thePlayer.ticksExisted % 2 == 0) {
                        resetLVBoolean = true
                        restVL.reset()
                    } else {
                        mc.timer.timerSpeed = 1f
                        resetLVBoolean = false;
                    }

                    var noramlOffset = doubleArrayOf(0.0266040404, 0.0113711, 0.02599360000000000332, 0.0376651233)
                    var vlResetOffset = doubleArrayOf(.1, .023)
                    if (randomCritBoolean) {
                        mc.timer.timerSpeed = if (resetLVBoolean) 0.8f else 1f
                        for (offset in if (resetLVBoolean) vlResetOffset else noramlOffset) {
                            if (debug.get())
                                thePlayer.addChatMessage(classProvider.createChatComponentText(if (resetLVBoolean) "[Crit w/ ResetLV]"+offset else "[Crit]"+offset))
                            mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                        }
                    }
                }
                "packet3" -> {
                    var randomCritBoolean = Random.nextBoolean()
                    var noramlOffset = doubleArrayOf(0.0200304, 0.0113711, 0.02159936000000332, 0.00276651233)
                    var movecheck = Math.abs(mc.thePlayer!!.motionX) < 0.1 || Math.abs(mc.thePlayer!!.motionZ) < 0.1
                    if (randomCritBoolean && !velocityInput && movecheck) {
                        for (offset in noramlOffset) {
                            if (debug.get())
                                thePlayer.addChatMessage(classProvider.createChatComponentText("[Crit] " + mc.thePlayer!!.ticksExisted))
                            mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerPosition(x, y + offset, z, false))
                        }
                    }
                }
            }

            msTimer.reset()
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet

        val thePlayer = mc.thePlayer ?: return
        if (classProvider.isSPacketEntityVelocity(packet)) {
            val packetEntityVelocity = packet.asSPacketEntityVelocity()
            if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer) {
                return

                velocityInput = true
            } else {
                velocityInput = false
            }
        }

        if (classProvider.isCPacketPlayer(packet) && modeValue.get().equals("NoGround", ignoreCase = true)) {
            packet.asCPacketPlayer().onGround = false
        }
        if (classProvider.isCPacketPlayer(packet) && modeValue.get().equals("C03", ignoreCase = true)) {
            packet.asCPacketPlayer().onGround = false
        }
        if(modeValue.get().equals("C03", ignoreCase = true)){
            mc.gameSettings.keyBindForward.pressed = false
            mc.gameSettings.keyBindLeft.pressed = false
            mc.gameSettings.keyBindRight.pressed = false
            mc.gameSettings.keyBindBack.pressed = false
            mc.gameSettings.keyBindJump.pressed = false
            mc.gameSettings.keyBindSneak.pressed = false
            if (classProvider.isCPacketPlayer(event.packet)){
                event.cancelEvent()
            }
            }
    }

    override val tag: String?
        get() = if (modeValue.get().contains("Packet")) "Packet" else modeValue.get()
}
