/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.RoundedUtil
import net.ccbluex.liquidbounce.value.*
import java.awt.Color
import java.text.SimpleDateFormat
import java.util.*

@ModuleInfo(name = "HUD", category = ModuleCategory.RENDER, array = false, description = "CatBounce", cn = "HUD")
class HUD : Module() {
    public val containerValue = BoolValue("Container", true)
    companion object {
        val shadowValue = ListValue("ShadowMode", arrayOf("LiquidBounce","Test","Test2", "Test3","Outline", "Default", "Autumn"), "LiquidBounce")
                     }
    private val toggleMessageValue = BoolValue("DisplayToggleMessage", true)
    private val toggleSoundValue = ListValue("ToggleSound", arrayOf("None", "Default", "Custom"), "Custom")
    val containerBackground = BoolValue("Container-Background", false)
    val animHotbarValue = BoolValue("AnimatedHotbar", true)
    val betterHealthValue = BoolValue("Better-Health", true)
    val inventoryParticle = BoolValue("InventoryParticle", false)
    private val blurValue = BoolValue("Blur", false)
    public val BlurStrength = FloatValue("BlurStrength", 15F, 0f, 30F)//这是模糊°
    val Radius = IntegerValue("BlurRadius", 10 , 1 , 50 )
    val fontChatValue = BoolValue("FontChat", false)
    val chatRect = BoolValue("ChatRect", false)
    val chatAnimValue = BoolValue("ChatAnimation", true)
    val logValue = ListValue("LogMode", arrayOf("CatBounce", "Jello","CatBounce2","CatBounce3"), "None")
    val hueInterpolation = BoolValue("HueInterpolate", false)
    val ClientName = TextValue("ClientName", "CatBounce")
    val Dev = TextValue("DevName", "Surplus")
    val r = IntegerValue("NovolineRed", 0, 0, 255)
    val g = IntegerValue("NovolineGreen", 255, 0, 255)
    val b = IntegerValue("NovolineBlue", 255, 0, 255)
    val r2 = IntegerValue("NovolineRed2", 255, 0, 255)
    val g2 = IntegerValue("NovolineGreen2", 40, 0, 255)
    val b2 = IntegerValue("NovolineBlue2", 255, 0, 255)
    val rainbowStartValue = FloatValue("RainbowStart", 0.41f, 0f, 1f)
    val rainbowStopValue = FloatValue("RainbowStop", 0.58f, 0f, 1f)
    val blurmoduleValue = BoolValue("Moduleblur", false)
    val shadow = BoolValue("Shadow", false)
    val shadowred = IntegerValue("ShadowRed", 0,0,255 )
    val shadowgreen =  IntegerValue("ShadowGreen", 0,0,255 )
    val shadowblue =  IntegerValue("ShadowBlue", 0,0,255)
    val shadowalpha =  IntegerValue("Shadowalpha", 0,0,255 )
    val rainbowSaturationValue = FloatValue("RainbowSaturation", 0.7f, 0f, 1f)
    val rainbowBrightnessValue = FloatValue("RainbowBrightness", 1f, 0f, 1f)
    val rainbowSpeedValue = IntegerValue("RainbowSpeed", 1500, 500, 7000)


    //color
    private var gradientColor1 = Color.WHITE
    private  var gradientColor2:java.awt.Color? = java.awt.Color.WHITE
    private  var gradientColor3:java.awt.Color? = java.awt.Color.WHITE
    private  var gradientColor4:java.awt.Color? = java.awt.Color.WHITE
    private var hotBarX = 0F
    fun getClientColor(): Color {
        return Color(r.get(),g.get(),b.get(),200)
    }

    fun getAlternateClientColor(): Color {
        return Color(r2.get(),g2.get(),b2.get(),200)
    }

    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        LiquidBounce.hud.render(false)
        when (logValue.get().toLowerCase()) {
            "catbounce" -> {
                gradientColor1 = net.ccbluex.liquidbounce.utils.render.RenderUtils.interpolateColorsBackAndForth(
                        15,
                        0,
                        getClientColor(),
                        getAlternateClientColor(),
                        hueInterpolation.get()
                )
                gradientColor2 = net.ccbluex.liquidbounce.utils.render.RenderUtils.interpolateColorsBackAndForth(
                        15,
                        90,
                        getClientColor(),
                        getAlternateClientColor(),
                        hueInterpolation.get()
                )
                gradientColor3 = net.ccbluex.liquidbounce.utils.render.RenderUtils.interpolateColorsBackAndForth(
                        15,
                        180,
                        getClientColor(),
                        getAlternateClientColor(),
                        hueInterpolation.get()
                )
                gradientColor4 = net.ccbluex.liquidbounce.utils.render.RenderUtils.interpolateColorsBackAndForth(
                        15,
                        270,
                        getClientColor(),
                        getAlternateClientColor(),
                        hueInterpolation.get()
                )
                val timeB = SimpleDateFormat("HH:mm").format(Calendar.getInstance().time)
                RoundedUtil.drawGradientRound(10f,10f,100f+20f,15f,7f,gradientColor1,gradientColor2,gradientColor3,gradientColor4)//?
                Fonts.sfbold40.drawCenteredString(ClientName.get() +"  "+"Dev-"+ Dev.get(), 70f, 14f, Color.WHITE.rgb,true)
            }
            "jello" ->{
                RenderUtils.drawImage(classProvider.createResourceLocation("jello/jello.png"), 10, 4, 86, 49)
            }
            "CatBounce2" ->{
                RenderUtils.drawImage(classProvider.createResourceLocation("jello/CatBounce2.png"), 10, 4, 86, 49)
            }
            "CatBounce3" ->{
                RenderUtils.drawImage(classProvider.createResourceLocation("jello/CatBounce3.png"), 10, 4, 120, 25)
            }
        }
        if (classProvider.isGuiHudDesigner(mc.currentScreen))
            return

        LiquidBounce.hud.render(false)
    }


    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }
    @EventTarget(ignoreCondition = true)
    fun onTick(event: TickEvent) {
        LiquidBounce.moduleManager.shouldNotify = toggleMessageValue.get()
        LiquidBounce.moduleManager.toggleSoundMode = toggleSoundValue.values.indexOf(toggleSoundValue.get())
    }
    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }
    fun getAnimPos(pos: Float): Float {
        if (state && animHotbarValue.get()) hotBarX = net.ccbluex.liquidbounce.utils.AnimationUtils.animate(pos, hotBarX, 0.02F * RenderUtils.deltaTime.toFloat())
        else hotBarX = pos

        return hotBarX
    }

    init {
        state = true
    }

    @EventTarget(ignoreCondition = true)
    fun onScreen(event: ScreenEvent) {
        if (mc.theWorld == null || mc.thePlayer == null) return
        if (state && blurValue.get() && !mc.entityRenderer.isShaderActive() && event.guiScreen != null &&
                !(classProvider.isGuiChat(event.guiScreen) || classProvider.isGuiHudDesigner(event.guiScreen))) mc.entityRenderer.loadShader(classProvider.createResourceLocation(LiquidBounce.CLIENT_NAME.toLowerCase() + "/blur.json")) else if (mc.entityRenderer.shaderGroup != null &&
                mc.entityRenderer.shaderGroup!!.shaderGroupName.contains("catbounce/blur.json")) mc.entityRenderer.stopUseShader()
    }

    init {
        state = true
    }


}