package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.api.minecraft.potion.IPotion
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "PotionWarn ", description = "Check Potion Warn", category = ModuleCategory.MISC, cn = "药水检测")
class PotionWarn : Module(){
    private val checkPotionNameValue = ListValue("CheckPotionName", arrayOf("DamageBoost","MoveSpeed","Jump","Regen"),"DamageBoost")
    private var checkPotionName: String = ""
    var a = 0
    @EventTarget
    fun onUpdate(event: UpdateEvent){
        a += 1
        if (mc.thePlayer!!.ticksExisted %2 == 0) {
            for (entity in mc.theWorld!!.loadedEntityList) {
                if (entity != null && entity != mc.thePlayer && classProvider.isEntityPlayer(entity) && entity.asEntityLivingBase().isPotionActive(potionActiveName(checkPotionNameValue.get())!!) && EntityUtils.isSelected(entity,true)) {
                        if(mc.thePlayer!!.getDistanceToEntity(entity) >= 4.3 && a >= 50) {
                            a = 0
                            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]"  + "§b检测到§a" + entity.name + "§b喝了§c§l${checkPotionName}§b，离你:[§a" + mc.thePlayer!!.getDistanceToEntity(entity) + "§b]")
                        }
                }
            }
        }
        when(checkPotionNameValue.get().toLowerCase()){
            "damageboost" -> checkPotionName = "力量"
            "movespeed" -> checkPotionName = "速度"
            "jump‘" -> checkPotionName = "跳跃"
            "regen" -> checkPotionName = "恢复"
        }
    }
    fun potionActiveName(potionName: String): IPotion?{
        return when(potionName.toLowerCase()) {
            "damageboost" -> classProvider.getPotionEnum(PotionType.STRENGTH)
            "movespeed" -> classProvider.getPotionEnum(PotionType.MOVE_SPEED)
            "jump" -> classProvider.getPotionEnum(PotionType.JUMP)
            "regen" -> classProvider.getPotionEnum(PotionType.REGENERATION)
            else -> null
        }
    }
}