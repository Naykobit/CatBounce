/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement


import me.utils.Debug.thePlayerisBlocking
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.enums.ItemType
import net.ccbluex.liquidbounce.api.enums.WEnumHand
import net.ccbluex.liquidbounce.api.minecraft.entity.player.IInventoryPlayer
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketClientStatus
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.ClassProviderImpl.createCPacketHeldItemChange
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.createUseItemPacket
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.*
import net.minecraft.block.BlockSlime
import net.minecraft.entity.player.InventoryPlayer
import net.minecraft.item.*
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.SPacketOpenWindow
import net.minecraft.network.play.server.SPacketWindowItems
import net.minecraft.util.EnumFacing
import net.minecraft.util.EnumHand
import net.minecraft.util.math.BlockPos
import sun.audio.AudioPlayer.player
import java.util.*

//跑吃使用的时候勾选food,canclesopen，doMess即可
//跑吃15s可以吃一次，剩下是0vl走吃
//Thank * and me
//*qq group :465850106
//catbounce qq group :553849936
@ModuleInfo(name = "NoSlow", description = "catbounce",
    category = ModuleCategory.MOVEMENT, cn = "无减速")
class NoSlow : Module() {

    val modeValue = ListValue("PacketMode", arrayOf("Vanilla", "Grimac","aac"), "Vanilla")
    private val blockForwardMultiplier = FloatValue("BlockForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val blockStrafeMultiplier = FloatValue("BlockStrafeMultiplier", 1.0F, 0.2F, 1.0F)

    private val consumeForwardMultiplier = FloatValue("ConsumeForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val consumeStrafeMultiplier = FloatValue("ConsumeStrafeMultiplier", 1.0F, 0.2F, 1.0F)

    private val bowForwardMultiplier = FloatValue("BowForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val bowStrafeMultiplier = FloatValue("BowStrafeMultiplier", 1.0F, 0.2F, 1.0F)
    private val doMess = BoolValue("doMess",  false)
    private val canclesopen = BoolValue("canclesopen",  true)
    private val food = BoolValue("food",  false)
    private val bugfood = BoolValue("bugfood",  false)
    private val Mess = TextValue("Message", "report")

    private var a = false
    private var sentpacket = false
    private var report = false
    private var c = false
    private var b = 0
    private var num = 0
    private val packet = BoolValue("Packet", true)

    // Soulsand
    val soulsandValue = BoolValue("Soulsand", true)
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        val heldItem = thePlayer.heldItem!!
        if (bugfood.get()){
            if(mc2.player.isHandActive){
                val item = mc2.player.inventory.getCurrentItem().item
                if((item is ItemFood || item is ItemPotion || item is ItemBucketMilk) ){
                    mc2.connection!!.sendPacket(classProvider.createCPacketClientStatus(ICPacketClientStatus.WEnumState.OPEN_INVENTORY_ACHIEVEMENT).unwrap())
                    consumeForwardMultiplier.set(1.0)
                    consumeStrafeMultiplier.set(1.0)
                }
            }
        }
        if (food.get() ){
            for (i in 0..8) {
                val itemStack = mc2.player.inventory.getCurrentItem()
                if (itemStack != null && itemStack.item is ItemFood){
                    if (itemStack.stackSize < num) {
                        c = false
                        mc.gameSettings.keyBindUseItem.pressed = false
                        mc.gameSettings.keyBindForward.pressed = false
                        mc.gameSettings.keyBindJump.pressed = false
                        ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d跑吃/走吃完请不要立马吃下一个食物哦!")
                    }
                    if (itemStack.stackSize != 0) {
                        num = itemStack.stackSize
                    }else{
                        num = 0
                    }
                }
            }
            if(!mc2.player.isHandActive){
                b += 1
                consumeForwardMultiplier.set(0.79)
                consumeStrafeMultiplier.set(0.20)
                if(a && (classProvider.isItemFood(heldItem.item) || classProvider.isItemPotion(
                        heldItem.item
                    ) || classProvider.isItemBucketMilk(heldItem.item))) {
                    mc.thePlayer!!.sprinting = false
                    mc.gameSettings.keyBindForward.pressed = false
                    mc.gameSettings.keyBindJump.pressed = false
                }
            }
            if(b >= 320 && a){
                a = false
                b = 0
                ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§c§d可以跑吃啦~")
            }
            if(mc2.player.isHandActive){
                val item = mc2.player.inventory.getCurrentItem().item
                if((item is ItemFood || item is ItemPotion || item is ItemBucketMilk) && !a ){
                    mc.thePlayer!!.sprinting = false
                    mc.gameSettings.keyBindJump.pressed = false
                    c=true
                    if(doMess.get()){
                        mc.thePlayer!!.sendChatMessage("/"+Mess.get())
                        report = true
                    }else{
                        mc.playerController.windowClick(mc.thePlayer!!.openContainer!!.windowId, 20, 1, 1,
                            mc.thePlayer!!
                        )
                    }
                    mc.thePlayer!!.sprinting = true
                    consumeForwardMultiplier.set(1.0)
                    consumeStrafeMultiplier.set(1.0)
                    a = true
                }
            }
        }
    }
    @EventTarget
    fun  onPacket(event: PacketEvent){
        val  e = event.packet.unwrap()
        if ((e is SPacketOpenWindow)&& canclesopen.get() && report){
            event.cancelEvent()
            report = false
        }
    }
    @EventTarget
    fun onMotion(event: MotionEvent) {
        val thePlayer = mc.thePlayer ?: return

        val heldItem = thePlayer.heldItem
        if (heldItem == null || !classProvider.isItemSword(heldItem.item) || !MovementUtils.isMoving) {
            return
        }
        if (!(mc.gameSettings.keyBindUseItem.isKeyDown)) {
            return
        }
        if (this.packet.get()) {
            when (modeValue.get().toLowerCase()) {
                "vanilla" -> {
                    when (event.eventState) {
                        EventState.PRE -> {
                            val digging = classProvider.createCPacketPlayerDigging(
                                ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                                WBlockPos.ORIGIN,
                                classProvider.getEnumFacing(
                                    EnumFacingType.DOWN
                                )
                            )
                            mc.netHandler.addToSendQueue(digging)
                        }

                        EventState.POST -> {
                            mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                            val blockPlace =
                                createUseItemPacket(thePlayer.inventory.getCurrentItemInHand(), WEnumHand.MAIN_HAND)
                            mc.netHandler.addToSendQueue(blockPlace)
                        }
                    }
                }
                "grimac" -> {
                    when (event.eventState) {
                        EventState.PRE -> {
                            mc2.connection!!.sendPacket(
                                CPacketPlayerDigging(
                                    CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                    BlockPos(0, 0, 0),
                                    EnumFacing.DOWN
                                )
                            )
                        }
                        EventState.POST -> {
                            mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                            mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                            mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.OFF_HAND))
                        }
                    }
                }
                "aac" -> {
                    when (event.eventState) {
                        EventState.PRE -> {
                            mc2.connection!!.sendPacket(
                                CPacketPlayerDigging(
                                    CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                    BlockPos(0, 0, 0),
                                    EnumFacing.DOWN
                                )
                            )
                        }
                        EventState.POST -> {
                            mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                            mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                            mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.OFF_HAND))
                        }
                    }
                }
            }
        }
    }

    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item

        event.forward = getMultiplier(heldItem, true)
        event.strafe = getMultiplier(heldItem, false)
    }

    private fun getMultiplier(item: IItem?, isForward: Boolean): Float {
        return when {
            classProvider.isItemFood(item) || classProvider.isItemPotion(item) || classProvider.isItemBucketMilk(item) -> {
                if (isForward) this.consumeForwardMultiplier.get() else this.consumeStrafeMultiplier.get()
            }
            classProvider.isItemSword(item) -> {
                if (isForward) this.blockForwardMultiplier.get() else this.blockStrafeMultiplier.get()
            }
            classProvider.isItemBow(item) -> {
                if (isForward) this.bowForwardMultiplier.get() else this.bowStrafeMultiplier.get()
            }
            else -> 0.2F
        }
    }

}


