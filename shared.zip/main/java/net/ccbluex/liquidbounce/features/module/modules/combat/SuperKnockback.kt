
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketEntityAction
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.CPacketEntityAction

@ModuleInfo(name = "SuperKnockback", category = ModuleCategory.COMBAT, description = "CatBounce", cn = "超凡脱俗的暴力冲击")
class SuperKnockback : Module() {
    private val hurtTimeValue = IntegerValue("HurtTime", 10, 0, 10)
    val modeValue = ListValue("Mode", arrayOf("Catbounce","Catbounce2", "HYTPacket","Strict","sneakpacket"), "Catbounce")
    private val reallyS = BoolValue("ReallyS", false)
    private var ticks = 0
    private var ticks2 = 0
    private var a = 0
    val timer = MSTimer()


    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (classProvider.isEntityLivingBase(event.targetEntity)) {
            if (event.targetEntity!!.asEntityLivingBase().hurtTime > hurtTimeValue.get())
                return

            when (modeValue.get()) {
                "Strict" -> {
                    ticks2 = 2
                }
                "Catbounce" -> {
                    val player = mc.thePlayer ?: return
                    if (mc2.player.isSprinting) {
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                    }
                    mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))
                    mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                    mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))

                    player.sprinting = true
                    player.serverSprintState = true
                }
                "sneakpacket" -> {
                    val player = mc.thePlayer ?: return
                    if (RotationUtils.getRotationDifference(Rotation(MovementUtils.movingYaw, mc.thePlayer!!.rotationPitch), Rotation(mc.thePlayer!!.rotationYaw, mc.thePlayer!!.rotationPitch)) > 30
                        || !MovementUtils.isMoving) {

                        if (mc2.player.isSprinting) {
                            mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                        }
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))

                        player.sprinting = true
                        player.serverSprintState = true

                        return
                    }
                    if (mc2.player.isSprinting) {
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                        mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SNEAKING))
                    }
                    mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SNEAKING))
                    mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))

                    player.sprinting = true
                    player.serverSprintState = true
                }
                "Catbounce2" -> {
                        if (mc2.player.isSprinting){
                            mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                            mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))
                            ticks = 2
                        }else{
                            mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.START_SPRINTING))
                            mc2.connection!!.networkManager.sendPacket(CPacketEntityAction(mc2.player, CPacketEntityAction.Action.STOP_SPRINTING))
                            ticks = 2
                        }
                }
                "hytpacket" -> {
                    if (mc2.player.isSprinting)
                        mc2.player.isSprinting = true
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.STOP_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.START_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.STOP_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.START_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.STOP_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.START_SPRINTING))
                    mc.netHandler.addToSendQueue(classProvider.createCPacketEntityAction(mc.thePlayer!!, ICPacketEntityAction.WAction.STOP_SPRINTING))
                    mc.thePlayer!!.serverSprintState = true
                    ticks = 2
                }
                }
            timer.reset()
        }
    }


    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        a += 1;
        if(!mc.thePlayer!!.onGround) a = 0
        if (reallyS.get()) {
                if (ticks == 2) {
                    mc2.player.isSprinting = false
                    ticks = 1
                } else if (ticks == 1) {
                    mc2.player.isSprinting = true
                    ticks = 0
                }
        }
        if (reallyS.get()) {
            if (ticks2 == 2) {
                mc.gameSettings.keyBindForward.pressed = false
                ticks = 1
            } else if (ticks2 == 1) {
                mc.gameSettings.keyBindForward.pressed = true
                ticks = 0
            }
        }
    }

    override fun onEnable() {
        a = 0
    }
    override val tag: String
        get() = modeValue.get()
}
