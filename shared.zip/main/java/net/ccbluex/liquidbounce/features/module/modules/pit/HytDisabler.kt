package net.ccbluex.liquidbounce.features.module.modules.pit

import me.utils.PacketUtils
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.CPacketConfirmTransaction
import net.minecraft.network.play.client.CPacketKeepAlive
import net.minecraft.network.play.server.SPacketPlayerPosLook
import java.util.*


@ModuleInfo(name = "HytDisabler", description = "Disable some anticheats' checks.", category = ModuleCategory.FUN, cn = "HYT屏蔽器")
class HytDisabler : Module() {

    val modeValue = ListValue(
        "Mode",
        arrayOf(
            "HytSpartan",
            "PingSpoof",
            "hytaac"
        ), "HytSpartan"
    )
    private val HytAAC = BoolValue("HytAAC", false)
    private val minpsf: IntegerValue = object : IntegerValue("PingSpoof-MinDelay", 0, 0, 10000, "ms", { modeValue.get().equals("pingspoof", true) }) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val v = maxpsf.get()
            if (v < newValue) set(v)
        }
    }
    private val maxpsf: IntegerValue = object : IntegerValue("PingSpoof-MaxDelay", 0, 0, 10000, "ms", { modeValue.get().equals("pingspoof", true) }) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val v = minpsf.get()
            if (v > newValue) set(v)
        }
    }
    private val psfStartSendMode = ListValue("PingSpoof-StartSendMode", arrayOf("All", "First"), "All", { modeValue.get().equals("pingspoof", true) })
    private val psfSendMode = ListValue("PingSpoof-SendMode", arrayOf("All", "First"), "All", { modeValue.get().equals("pingspoof", true) })
    private val psfWorldDelay = IntegerValue("PingSpoof-WorldDelay", 15000, 0, 30000, "ms", { modeValue.get().equals("pingspoof", true) })
    // debug
    private val debugValue = BoolValue("Debug", false)


    // variables
    private val queueBus = LinkedList<Packet<INetHandlerPlayServer>>()
    private val keepAlives = arrayListOf<CPacketKeepAlive>()
    private val transactions = arrayListOf<CPacketConfirmTransaction>()
    private val msTimer = MSTimer()
    private var sendDelay = 0
    private var shouldActive = false
    private var benHittingLean = false
    fun debug(s: String) {
        if (debugValue.get())
            ClientUtils.displayChatMessage("§7[§3§lDisabler§7]§f $s")

    }
    override fun onDisable() {



        if (modeValue.get().equals("pingspoof", true)) {
            // make sure not to cause weird flag
            for (p in queueBus)
                PacketUtils.sendPacketNoEvent(p)
        }

    }
    @EventTarget
    fun onPacket(event: PacketEvent) {

        var packet = event.packet
        when (modeValue.get().toLowerCase()) {
            "pingspoof" -> {
                if (packet is CPacketConfirmTransaction && (transactions.size <= 0 || packet != transactions[transactions.size - 1])) {
                    queueBus.add(packet)
                    event.cancelEvent()

                    debug("c0f added, action id ${packet.uid}, target id ${packet.windowId}")
                }
                if (packet is CPacketKeepAlive) {
                    queueBus.add(packet)
                    event.cancelEvent()

                    debug("c00 added, key ${packet.key}")
                }
            }
            "hytspartan" -> {
                if (packet is CPacketKeepAlive && (keepAlives.size <= 0 || packet != keepAlives[keepAlives.size - 1])) {
                    debug("c00 added")
                    keepAlives.add(packet)
                    event.cancelEvent()
                }
                if (packet is CPacketConfirmTransaction && (transactions.size <= 0 || packet != transactions[transactions.size - 1])) {
                    debug("c0f added")
                    transactions.add(packet)
                    event.cancelEvent()
                }
            }
            "hytaac" -> {
                if(HytAAC.get()) {
                 (event.packet is SPacketPlayerPosLook)
                    val s08 = event.packet
                    debug("[Disabler] 屏蔽S类型发包数据")
                }
            }
        }
        fun flush(check: Boolean) {
            if ((if (check) psfSendMode.get() else psfStartSendMode.get()).equals("all", true))
                while (queueBus.size > 0) {
                    PacketUtils.sendPacketNoEvent(queueBus.poll())
                }
            else
                PacketUtils.sendPacketNoEvent(queueBus.poll())
        }
        @EventTarget
        fun onUpdate(event: UpdateEvent) {
            when (modeValue.get().toLowerCase()) {
                "pingspoof" -> {
                    if (msTimer.hasTimePassed(psfWorldDelay.get().toLong()) && !shouldActive) {
                        shouldActive = true
                        sendDelay = RandomUtils.nextInt(minpsf.get(), maxpsf.get())
                        if (queueBus.size > 0) flush(false)
                        msTimer.reset()
                        debug("activated. expected next delay: ${sendDelay}ms")
                    }

                    if (shouldActive) {
                        if (msTimer.hasTimePassed(sendDelay.toLong()) && !queueBus.isEmpty()) {
                            flush(true)
                            sendDelay = RandomUtils.nextInt(minpsf.get(), maxpsf.get())
                            msTimer.reset()
                            debug("expected next delay: ${sendDelay}ms")
                        }
                    }
                }
                "hytspartan" -> {
                    if (msTimer.hasTimePassed(3000L) && keepAlives.size > 0 && transactions.size > 0) {
                        PacketUtils.send(keepAlives[keepAlives.size - 1])
                        PacketUtils.send(transactions[transactions.size - 1])

                        debug("c00 no.${keepAlives.size - 1} sent.")
                        debug("c0f no.${transactions.size - 1} sent.")
                        keepAlives.clear()
                        transactions.clear()
                        msTimer.reset()
                    }
                }
            }
        }
    }
}

