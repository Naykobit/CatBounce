/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.misc.Reallyhurt
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "balantaura", description = "catbounce", category = ModuleCategory.COMBAT, cn = "极度暴力模式")
class balantaura : Module() {
    private lateinit var killAura: KillAura

    override fun onEnable() {
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura

        killAura.hitableValue.set(true)

    }

    override fun onDisable() {
        killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura

        killAura.hitableValue.set(false)
    }

}