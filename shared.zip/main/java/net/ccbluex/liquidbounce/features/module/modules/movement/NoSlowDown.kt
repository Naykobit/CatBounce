
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayer
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.C08PacketPlayerBlockPlacement
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.item.ItemBucketMilk
import net.minecraft.item.ItemFood
import net.minecraft.item.ItemPotion
import net.minecraft.item.ItemSword
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.*
import net.minecraft.util.EnumFacing
import net.minecraft.util.EnumHand
import net.minecraft.util.math.BlockPos
import java.util.*


@ModuleInfo(
    name = "NoSlowDown", description = "快速死号",
    category = ModuleCategory.MOVEMENT, cn = "无减速修复"

)
class NoSlowDown : Module() {

    private val modeValue = ListValue(
        "PacketMode",
        arrayOf("test", "test2", "block", "block2", "block3"),
        "test2"
    )
    private val blockForwardMultiplier = FloatValue("BlockForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val blockStrafeMultiplier = FloatValue("BlockStrafeMultiplier", 1.0F, 0.2F, 1.0F)
    private val consumeForwardMultiplier = FloatValue("ConsumeForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val consumeStrafeMultiplier = FloatValue("ConsumeStrafeMultiplier", 1.0F, 0.2F, 1.0F)
    private val bowForwardMultiplier = FloatValue("BowForwardMultiplier", 1.0F, 0.2F, 1.0F)
    private val bowStrafeMultiplier = FloatValue("BowStrafeMultiplier", 1.0F, 0.2F, 1.0F)
    private val food = BoolValue("food",  false)

    private val Mess = TextValue("Message", "report")
    private var a = false
    private var b = 0
    private var blocking = false
    private val Timer = MSTimer()
    private var pendingFlagApplyPacket = false
    private val msTimer = MSTimer()
    private var sendBuf = false
    private var packetBuf = LinkedList<Packet<INetHandlerPlayServer>>()
    private var nextTemp = false
    private var waitC03 = false
    private var packet = 0

    private fun OnPre(event: MotionEvent): Boolean {
        return event.eventState == EventState.PRE
    }

    private fun OnPost(event: MotionEvent): Boolean {
        return event.eventState == EventState.POST
    }

    override fun onDisable() {
        Timer.reset()
        msTimer.reset()
        pendingFlagApplyPacket = false
        sendBuf = false
        packetBuf.clear()
        nextTemp = false
        waitC03 = false
    }

    private fun sendPacket(
        Event: MotionEvent,
        SendC07: Boolean,
        SendC08: Boolean,
        Delay: Boolean,
        DelayValue: Long,
        onGround: Boolean,
        Hypixel: Boolean = false
    ) {
        val aura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura
        val digging = classProvider.createCPacketPlayerDigging(
            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
            WBlockPos(-1, -1, -1),
            EnumFacing.DOWN as IEnumFacing
        )
        val blockPlace =
            classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.currentItem as IItemStack)
        val blockMent = classProvider.createCPacketPlayerBlockPlacement(
            WBlockPos(-1, -1, -1),
            255,
            mc.thePlayer!!.inventory.currentItem as IItemStack,
            0f,
            0f,
            0f
        )
        if (onGround && !mc.thePlayer!!.onGround) {
            return
        }
        if (SendC07 && OnPre(Event)) {
            if (Delay && Timer.hasTimePassed(DelayValue)) {
                mc.netHandler.addToSendQueue(digging)
            } else if (!Delay) {
                mc.netHandler.addToSendQueue(digging)
            }
        }
        if (SendC08 && OnPost(Event)) {
            if (Delay && Timer.hasTimePassed(DelayValue) && !Hypixel) {
                mc.netHandler.addToSendQueue(blockPlace)
                Timer.reset()
            } else if (!Delay && !Hypixel) {
                mc.netHandler.addToSendQueue(blockPlace)
            } else if (Hypixel) {
                mc.netHandler.addToSendQueue(blockMent)
            }
        }
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (food.get()) {
            if (!mc2.player.isHandActive) {
                b += 1
            }
            if (b >= 5) {
                a = false
                b = 0
            }
            if (mc2.player.isHandActive) {
                val item = mc2.player.inventory.getCurrentItem().item
                if ((item is ItemFood || item is ItemPotion || item is ItemBucketMilk) && !a) {
                    mc.thePlayer!!.sendChatMessage("/" + Mess.get())
                }
            }
        }
    }
    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (!MovementUtils.isMoving) {
            return
        }
        when (modeValue.get().toLowerCase()) {
            "test" -> {

                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                    val thePlayer = mc.thePlayer ?: return
                    val heldItem = thePlayer.heldItem
                    val heldItemChange =
                        (classProvider.isItemBow(heldItem!!.item) || classProvider.isItemFood(heldItem.item) || classProvider.isItemPotion(
                            heldItem.item
                        ) || classProvider.isItemBucketMilk(heldItem.item))
                    val Sword = classProvider.isItemSword(mc.thePlayer!!.heldItem?.item)
                    val Block = classProvider.isItemBlock(mc.thePlayer!!.heldItem?.item)
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "test2" -> {
                if ((event.eventState == EventState.PRE && mc.thePlayer!!.itemInUse != null && mc.thePlayer!!.itemInUse!!.item != null) && !mc.thePlayer!!.isBlocking && classProvider.isItemFood(
                        mc.thePlayer!!.heldItem!!.item
                    ) || classProvider.isItemPotion(mc.thePlayer!!.heldItem!!.item)
                ) {
                    if (mc.thePlayer!!.onGround) {
                        if (mc.thePlayer!!.isUsingItem && mc.thePlayer!!.itemInUseCount >= 1) {
                            if (mc.thePlayer!!.sprinting) {
                                if (!mc.thePlayer!!.onGround) {
                                    mc.thePlayer!!.sprinting = false
                                }
                            }
                            if (mc.thePlayer!!.ticksExisted % 2 == 0) {
                                mc.thePlayer!!.sprinting = false
                            } else {
                                mc.thePlayer!!.sprinting = true
                            }
                            return
                        }
                    }
                }
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.timer.timerSpeed = 1.0F
                    mc.netHandler.addToSendQueue(
                        classProvider.createCPacketPlayerDigging(
                            ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                            WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                        )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "Block" -> {
                val item = mc2.player.inventory.getCurrentItem().item


                if(mc2.player.isHandActive){

                    if(item is ItemSword){
                        if(event.eventState.equals(EventState.PRE)){
                            mc2.connection!!.sendPacket(CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                BlockPos(0,0,0),EnumFacing.DOWN))
                        }
                        if(event.eventState.equals(EventState.POST)){
                            mc2.connection!!.sendPacket(CPacketConfirmTransaction())
                            mc2.connection!!.sendPacket(CPacketPlayerTryUseItem(EnumHand.MAIN_HAND))
                        }
                    }

                }
            }
            "Block2" -> {
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "Block3" -> {
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
        }

    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (modeValue.get() == "Block" && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item) &&
            packet is CPacketPlayerTryUseItem
        ){
            event.cancelEvent()
        }
        if (modeValue.get() == "Block2" && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item) &&
            packet is CPacketPlayerDigging
        ){
            event.cancelEvent()
        }
        if (modeValue.get() == "Block3" && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item) &&
            packet is CPacketEntityAction
        ){
            event.cancelEvent()
        }
    }


    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item

        event.forward = getMultiplier(heldItem, true)
        event.strafe = getMultiplier(heldItem, false)
    }

    private fun getMultiplier(item: IItem?, isForward: Boolean): Float {
        return when {
            classProvider.isItemFood(item) || classProvider.isItemPotion(item) || classProvider.isItemBucketMilk(item) -> {
                if (isForward) this.consumeForwardMultiplier.get() else this.consumeStrafeMultiplier.get()
            }
            classProvider.isItemSword(item) -> {
                if (isForward) this.blockForwardMultiplier.get() else this.blockStrafeMultiplier.get()
            }
            classProvider.isItemBow(item) -> {
                if (isForward) this.bowForwardMultiplier.get() else this.bowStrafeMultiplier.get()
            }

            else -> 0F
        }
    }
    override val tag: String
        get() = modeValue.get()
}




