package net.ccbluex.liquidbounce.features.module.modules.misc

import me.sound.SoundPlayer
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.network.play.server.SPacketChat
import java.awt.SystemTray
import java.awt.Toolkit
import java.awt.TrayIcon

@ModuleInfo(name = "AutoGG", category = ModuleCategory.MISC, description = "CatBounce", cn = "自动报喜")
class AutoGG : Module() {
    private val textValue = TextValue("Text", "GG")
    var totalPlayed = 0
    var win = 0
    val winmodeValue = ListValue("WinSoundMode", arrayOf("克拉拉", "停云" ,"可莉" ,"派蒙" ,"景元" ,"虎克", "黑塔",
        "瓦尔特 ", "枫原万叶" ,"艾斯妲", "刃","王者荣耀","None"), "克拉拉")
    val startmodeValue = ListValue("StartSoundMode", arrayOf("佩拉","None"), "佩拉")
    private val Volume = FloatValue("Volume", 50f, 0f, 100f)
    private val Debug = BoolValue("advance", true)

    fun displayTray(Title: String, Text: String, type: TrayIcon.MessageType?) {
        if (SystemTray.isSupported()) {
            val image = Toolkit.getDefaultToolkit().createImage("Cat.png")
            val trayIcon = TrayIcon(image)
            trayIcon.isImageAutoSize = true
            trayIcon.toolTip = "System tray icon demo"
            trayIcon.displayMessage(Title, Text, type)
        }
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText

            if (!packet.chatComponent.unformattedText.contains(":") && (text.contains("恭喜", true)
                        || text.contains("${mc.thePlayer!!.name} 在地图", true) && text.contains("取得了一场游戏的胜利", true) )) {
                LiquidBounce.hud.addNotification(Notification("AutoGG", "殴打HYT成功啦", NotifyType.SUCCESS))
                mc.thePlayer!!.sendChatMessage(textValue.get())
                when (winmodeValue.get().toLowerCase()) {
                    "王者荣耀" -> SoundPlayer().playSound(SoundPlayer.SoundType.VICTORY, Volume.get());
                    "克拉拉" -> SoundPlayer().playSound(SoundPlayer.SoundType.KELALAWIN, Volume.get());
                    "停云" -> SoundPlayer().playSound(SoundPlayer.SoundType.TINYUNWIN, Volume.get());
                    "可莉" -> SoundPlayer().playSound(SoundPlayer.SoundType.KELIWIN, Volume.get());
                    "派蒙"  -> SoundPlayer().playSound(SoundPlayer.SoundType.PAIMENWIN, Volume.get());
                    "景元"  -> SoundPlayer().playSound(SoundPlayer.SoundType.JINYUANWIN, Volume.get());
                    "虎克" -> SoundPlayer().playSound(SoundPlayer.SoundType.HUKEWIN, Volume.get());
                    "黑塔" -> SoundPlayer().playSound(SoundPlayer.SoundType.HEITAWIN, Volume.get());
                    "瓦尔特 " -> SoundPlayer().playSound(SoundPlayer.SoundType.WATWIN, Volume.get());
                    "枫原万叶" -> SoundPlayer().playSound(SoundPlayer.SoundType.FENGYUANWIN, Volume.get());
                    "艾斯妲" -> SoundPlayer().playSound(SoundPlayer.SoundType.AISHIDAWIN, Volume.get());
                    "刃" -> SoundPlayer().playSound(SoundPlayer.SoundType.LENGWIN, Volume.get());
                }
                if (Debug.get()) {
                    displayTray("恭喜胜利", "CatBounce 1.12.2", TrayIcon.MessageType.WARNING)
                }
                win++
            }
            if (!packet.chatComponent.unformattedText.contains(":") && text.contains("游戏开始", true)) {
                LiquidBounce.hud.addNotification(Notification("AutoGG", "游戏开始！！", NotifyType.SUCCESS))
                when (startmodeValue.get().toLowerCase()) {
                    "佩拉" -> SoundPlayer().playSound(SoundPlayer.SoundType.PEILABEGIN, Volume.get());
                }
                totalPlayed++
            }
        }
    }
    override val tag: String
        get() = "HuaYuTing"
}