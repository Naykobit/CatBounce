/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class IntaveHop : SpeedMode("IntaveHop") {
    private var offGroundTicks = 0
    private var jumped = false

    override fun onMotion(event: MotionEvent) {
          offGroundTicks++
        if (mc.thePlayer!!.onGround) {
            if (jumped) MovementUtils.strafe((MovementUtils.speed * 1.2).toFloat()) // ignore it in first jump
            offGroundTicks = 0
            mc.thePlayer!!.jump()
            jumped = true
        } else if (offGroundTicks == 4) { mc.thePlayer!!.motionY = -0.0784000015258789 }
    }

    override fun onEnable() {
        jumped = !mc.thePlayer!!.onGround
    }
    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {}
}