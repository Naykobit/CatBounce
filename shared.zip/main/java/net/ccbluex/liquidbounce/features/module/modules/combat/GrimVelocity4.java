package net.ccbluex.liquidbounce.features.module.modules.combat;

import java.lang.reflect.Field;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.multiplayer.IWorldClient;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.event.TickEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.misc.Nolagban;
import net.ccbluex.liquidbounce.features.module.modules.movement.EntitySpeed;
import net.ccbluex.liquidbounce.injection.backend.MinecraftImpl;
import net.ccbluex.liquidbounce.injection.backend.PacketImpl;
import net.ccbluex.liquidbounce.injection.backend.WorldClientImpl;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.utils.block.BlockUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Timer;
import net.minecraft.util.math.BlockPos;

/**
 *Skid By GaoWenBo
 * @author 7078z
 *@Data 2023.9.26
 *
 * 泛滥狗 1670007933 替换class大神 也是一条缺钱的恶狗
 *改description 的死了亲娘了
 */
@ModuleInfo(name="GrimVelocity", description="7078z", category=ModuleCategory.COMBAT,cn="Grim全反")
public final class GrimVelocity4
        extends Module {
    private final BoolValue sendC03Value = new BoolValue("SendC03", true);

    private final BoolValue sendC03Value2 = new BoolValue("SendC03_type_c", true);

    private final BoolValue sendC07Value = new BoolValue("SendC07", false);

    private final BoolValue cancle = new BoolValue("CancleS12", false);

    private final BoolValue breakValue = new BoolValue("BreakBlock", true);
    private final BoolValue alwayValue = new BoolValue("Alway", false);



    private boolean gotVelo = false;
    private boolean lastWasTeleport = false;
    private boolean walkingDown = false;


    @Override
    public void onEnable() {
        this.gotVelo = false;
        this.lastWasTeleport = false;
    }

    @EventTarget
    public final void onTick(final TickEvent event) {
        IEntityPlayerSP thePlayer = mc.getThePlayer();
        if (thePlayer == null) return;
        IWorldClient theWorld = mc.getTheWorld();
        if (theWorld == null) return;
        Timer timer = ((MinecraftImpl) mc).getWrapped().timer;
        if (timer == null) return;
        if (this.alwayValue.get() || this.gotVelo) {
            NetHandlerPlayClient connection = ((MinecraftImpl) mc).getWrapped().getConnection();
            if (connection == null) return;
            this.gotVelo = false;
            if (this.sendC03Value.get()) {
                if(this.sendC03Value2.get() && !mc.getThePlayer().getOnGround()) {
                    connection.sendPacket(new CPacketPlayer());
                }else{
                    connection.sendPacket(new CPacketPlayer(thePlayer.getOnGround()));
                }
                try {
                    Field f = timer.getClass().getDeclaredField("field_74277_g");
                    f.setAccessible(true);
                    long t = (long) f.get(timer);
                    f.set(timer, t + 50L);
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            BlockPos pos = new BlockPos(thePlayer.getPosX(), thePlayer.getPosY() + 1.0, thePlayer.getPosZ());
            BlockPos pos2 = new BlockPos(thePlayer.getPosX(), thePlayer.getPosY(), thePlayer.getPosZ());
            if (this.sendC07Value.get()) {
                if (classProvider.isBlockStairs(BlockUtils.getBlock(new WBlockPos(thePlayer.getPosX(), thePlayer.getEntityBoundingBox().getMinY(), thePlayer.getPosZ())))
                        && !walkingDown){
                    connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.DOWN));
                    if (this.breakValue.get())
                        ((WorldClientImpl) theWorld).getWrapped().setBlockToAir(pos);
                }else{
                    if(mc.getThePlayer().getOnGround()){
                        connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.DOWN));
                        if (this.breakValue.get())
                            ((WorldClientImpl) theWorld).getWrapped().setBlockToAir(pos);
                    }else{
                        connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos2, EnumFacing.DOWN));
                        if (this.breakValue.get())
                            ((WorldClientImpl) theWorld).getWrapped().setBlockToAir(pos2);
                    }
                }
            }
        }
    }
    @EventTarget
    public final void onUpdate(final UpdateEvent event) {
        IEntityPlayerSP thePlayer = mc.getThePlayer();
        if (thePlayer.getFallDistance() > 0 && !walkingDown)
            walkingDown = true;
        else if (thePlayer.getPosY() > thePlayer.getPrevChasingPosY())
            walkingDown = false;
    }
    @EventTarget
    public final void onPacket(final PacketEvent event) {
        IEntityPlayerSP thePlayer = mc.getThePlayer();
        if (thePlayer == null) return;
        Packet<?> packet = ((PacketImpl) event.getPacket()).getWrapped();
        if (packet instanceof SPacketPlayerPosLook) {
            this.lastWasTeleport = true;
        } else if (!this.lastWasTeleport && packet instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity veloPacket = (SPacketEntityVelocity) packet;
            if (veloPacket.getEntityID() == thePlayer.getEntityId()) {
                if(cancle.get()) event.cancelEvent();
                this.gotVelo = true;
            }
        } else if (packet instanceof SPacketExplosion) {
            SPacketExplosion veloPacket = (SPacketExplosion) packet;
            if (veloPacket.getMotionX() != 0f || veloPacket.getMotionY() != 0f || veloPacket.getMotionZ() != 0f) {
                event.cancelEvent();
                this.gotVelo = true;
            }
        } else if (packet.getClass().getName().startsWith("net.minecraft.network.play.server.SPacket")) {
            this.lastWasTeleport = false;
        }
    }
}