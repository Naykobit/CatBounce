/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.minecraft.network.play.server.SPacketExplosion

@ModuleInfo(name = "DamageFLY", category = ModuleCategory.MOVEMENT, description = "Stevie", cn = "伤害飞行")
class BoomFLY : Module() {
    private var tick = 0
    private var s = 0
    var hasReported = false
    private var velocitypacket = false

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!mc.thePlayer!!.onGround) {
            tick++
        } else {
            tick = 0
            s = 0
        }
        if (tick >= 20) {
            s += 1
            tick = 0
            hasReported = false
        }
        if (s >= 1 && !hasReported){
            ClientUtils.displayChatMessage("§8[§c§lCatBounce§8]§b§d您已飞行了${s}秒")
            hasReported = true
        }
        if (velocitypacket){
            mc.thePlayer!!.setPositionAndRotation(mc.thePlayer!!.posX+50, mc.thePlayer!!.posY, mc.thePlayer!!.posZ+50, mc.thePlayer!!.rotationYaw, mc.thePlayer!!.rotationPitch);
            velocitypacket = false
        }
    }
    override fun onEnable() {
        velocitypacket = false
    }

    fun onPacket(event: PacketEvent) {
        val packet = event.packet

        if (packet is SPacketExplosion) {
            velocitypacket = true
        }
    }
}
