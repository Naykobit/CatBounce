package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.BlockType
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.init.Blocks
import net.minecraft.network.play.server.SPacketEntityVelocity
import net.minecraft.network.play.server.SPacketPlayerPosLook



@ModuleInfo(name = "GrimVel", description = "cat",cn="不动如山", category = ModuleCategory.COMBAT)
class GrimVel : Module() {
    private var sendc07 = false
    private var diggingtime = 0
    private val reEnable = BoolValue("ReEnable",true)
    private val boom = BoolValue("boom",false)
    private val disable = BoolValue("S08Disable",true)
    private val NoMoveFix = BoolValue("1.12.2NoMoveFix",true)


    override fun onEnable() {
        sendc07 = false
    }

    @EventTarget
    fun onUpdate(event: MotionEvent) {
        val thePlayer = mc.thePlayer ?: return
        if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
            return
        if (mc.thePlayer!!.burning) return

        if(NoMoveFix.get() && !MovementUtils.isMoving && mc.thePlayer!!.onGround
            && mc.thePlayer!!.hurtTime == 9 && mc.thePlayer!!.motionX == 0.0
            && mc.thePlayer!!.motionZ == 0.0 && mc.thePlayer!!.health > 0
            && !mc.gameSettings.keyBindJump.isKeyDown) mc.thePlayer!!.jump()

        if(event.eventState == EventState.PRE){
            if(sendc07) {
                var hand = mc.netHandler
                if(hand === null)return
                sendc07 = false
                mc.netHandler.addToSendQueue(
                    classProvider.createCPacketPlayerDigging(
                        ICPacketPlayerDigging.WAction.STOP_DESTROY_BLOCK,
                        WBlockPos(mc.thePlayer!!.posX, mc.thePlayer!!.posY + 1.0, mc.thePlayer!!.posZ),
                        classProvider.getEnumFacing(EnumFacingType.NORTH)
                    )
                )

            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        var packet = event.packet
        val e = event.packet.unwrap()
        if (classProvider.isSPacketPlayerPosLook(packet) ) return
        if (classProvider.isSPacketEntityVelocity(packet) || (classProvider.isSPacketExplosion(packet) && boom.get())) {

            val thePlayer = mc.thePlayer ?: return
            if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
                return
            if (mc.gameSettings.keyBindAttack.isKeyDown && mc.theWorld!!.getBlockState(mc.objectMouseOver!!.blockPos!!).block != classProvider.getBlockEnum(
                    BlockType.AIR)) {
                diggingtime += 5
            }else{
                diggingtime = 0
            }
            if (  diggingtime >= 5 && mc.theWorld!!.getBlockState(mc.objectMouseOver!!.blockPos!!).block != classProvider.getBlockEnum(
                    BlockType.AIR) && mc.gameSettings.keyBindAttack.isKeyDown ) return
            //Auto Disable
            if (e is SPacketPlayerPosLook) {
                if (disable.get()) {
                    val velocity = LiquidBounce.moduleManager.getModule(GrimVel::class.java) as GrimVel
                    val velocity2 = LiquidBounce.moduleManager.getModule(GrimVelocity4::class.java) as GrimVelocity4
                    velocity2.state = false
                    velocity.state = false
                    if (reEnable.get()) {
                        Thread {
                            try {
                                Thread.sleep(1000)
                                velocity.state = true
                                velocity2.state = true
                            } catch (ex: InterruptedException) {
                                ex.printStackTrace()
                            }
                        }.start()
                    }
                }
            }
            val packetEntityVelocity = packet.asSPacketEntityVelocity()
            if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                return
            sendc07 = true
            event.cancelEvent()
        }
    }



    override val tag: String?
        get() = "LatestGrimac"
}