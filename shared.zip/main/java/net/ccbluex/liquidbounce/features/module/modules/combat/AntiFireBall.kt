package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.network.IPacket
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue


@ModuleInfo(name = "AntiFireBall", description = ":/", cn = "自动防火球", category = ModuleCategory.COMBAT)
class AntiFireBall : Module() {
    private val swingValue = ListValue("Swing", arrayOf("Normal", "Packet", "None"), "Normal")
    private val timer = MSTimer()
    @EventTarget
    fun onUpdate(event: UpdateEvent) {

        for (entity in mc.theWorld!!.loadedEntityList) if (classProvider.isEntityFireball(entity)) {
            if ( mc.thePlayer!!.getDistanceToEntity(entity) < 6.0 && timer.hasTimePassed(0L)) {

                mc.thePlayer!!.sendQueue.addToSendQueue((classProvider.createCPacketUseEntity(entity, ICPacketUseEntity.WAction.ATTACK) as IPacket))
                if (swingValue.get().equals( "Normal")) {
                    mc.thePlayer!!.swingItem()
                } else if (swingValue.get().equals( "Packet")) {
                    mc.netHandler.addToSendQueue((classProvider.createCPacketAnimation() as IPacket))
                }
                timer.reset()
                break
            }
        }
    }
}
