/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */

package net.ccbluex.liquidbounce.api.minecraft.potion

enum class PotionType {
    JUMP,
    HEAL,
    REGENERATION,
    BLINDNESS,
    MOVE_SPEED,
    HUNGER,
    DIG_SLOWDOWN,
    CONFUSION,
    WEAKNESS,
    MOVE_SLOWDOWN,
    HARM,
    WITHER,
    POISON,
    NIGHT_VISION,
    STRENGTH
}