/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */

package net.ccbluex.liquidbounce.api.enums

enum class ItemType {
    MUSHROOM_STEW, BOWL, FLINT_AND_STEEL, LAVA_BUCKET, WRITABLE_BOOK, WATER_BUCKET, COMMAND_BLOCK_MINECART, POTION_ITEM, SKULL, ARMOR_STAND
}