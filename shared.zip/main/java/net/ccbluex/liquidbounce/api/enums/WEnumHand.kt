package net.ccbluex.liquidbounce.api.enums

enum class WEnumHand {
    MAIN_HAND, OFF_HAND
}